function setInitial() {
  $("#control-ring li").addClass("enabled");//最初设定每个按钮都为激活状态
  $("#control-ring li").attr("sign", "enabled");
  $("#info-bar").attr("sign", "disabled");
  var button = $("#control-ring li");
  $(".apb").click(function() { 
    robrotOperation(button, function() { bubbleCal($("#info-bar"));});
  });//机器人设置click事件
}

function getNumber(aim, callbacks) {
  target = $(aim);
  if (target.attr("sign") === "enabled") {
    $("#control-ring li").each(function() { //把其他按钮灭活
      if(this !== aim && $(this).attr("sign") !== "ready") {
        // $(this).attr("sign", "disabled");
        $(this).removeClass("enabled");
      }
    });
   target.children("span").addClass("read");
   target.children("span").text("...");//显示并写入span
   getMessage(target, target.children("span"), callbacks);
  }
}

function getMessage(target, child, callbacks) { //用get方法请求数据
  $.post("number.txt", function(data) {
    target.attr("sign", "ready");
    target.removeClass("enabled");
    child.text(data);

    $("#control-ring li").each(function(index, element) {
    if($(element).attr("sign") !== "ready") {
      $(element).attr("sign", "enabled");
      $(element).addClass("enabled");
    }
    });
  if(bubbleEnabled()) { 
  	$("#info-bar").addClass("enabled"); 
    $("#info-bar").attr("sign", "enabled");
    callbacks();
  }
  });
}

function bubbleEnabled() { //判断大气泡是否能点击（数据是否都得到）
  var judge = true;
  $("#control-ring li").each(function() {
    if ($(this).attr("sign") !== "ready") { judge = false; return;}
  });
  return judge;
}

function bubbleCal(target) { //计算所得随机数之和并显示
  var sum = 0;
  if(bubbleEnabled() && target.attr("sign") ==="enabled") {
    $("#control-ring li span").each(function(index, element) {
      sum += parseInt($(element).text());
  });
    target.text(sum);
    target.attr("sign", "disabled");
    target.removeClass("enabled");
  }
}

function clear() {
  $("#control-ring li span").removeClass("read");
  $("#control-ring li span").text('');
  $("#control-ring li").attr("sign", "");
  $("#info-bar").text("");
  $("#info-bar").removeClass("enabled");
}

function robrotOperation(circles, bubbleCal) {
    //使得程序按同时执行
    callback = function() { var t = setTimeout(bubbleCal, 500); };
    for (var i = 0; i <= 4; i++) {
      (function(i) {
        getNumber(circles[i], callback);
      })(i);
    }
}

$(document).ready(function() {
  setInitial();
  $("#at-plus-container").mouseenter(function() {  
    $("#control-ring li").addClass("enabled");//最初设定每个按钮都为激活状态
    $("#control-ring li").attr("sign", "enabled");
    $("#info-bar").attr("sign", "disabled");
  });
  $("#at-plus-container").mouseleave(function() { clear(); });
});