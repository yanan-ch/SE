
var state = new Array(0,0,0,0,0,0);
var request;

$(document).ready(function(){
    $.ajaxSetup({cache:false});
	$("#button").hover(function(){

		$(".message").text("").css("opacity","0");
		for(var i = 0; i <= 5; ++i){
			state[i] = 0;
		}


		if(request != null) request.abort(); 
		$("#info-bar").css("background-color", "#8E8E8E").unbind("click");
		$("#sum").text("");
		deletebutton();
		restartbutton();
		buttonclick();
	});



});

function buttonclick(){
	$(".apb").click(function(){
		state[5] = 1;
		for(var i = 1; i <= 5; ++i){
			$(".button" + i).click().unbind();	
		}

		$(".apb").unbind();
	});
}


function deletebutton(){
	for(var i = 1; i <= 5; ++i){
		if(state[i - 1] != 1){
			$(".button" + i).css("background-color", "#8E8E8E").unbind("click");

		}
	}
}

function restartbutton(){
	for(var i = 1; i <= 5; ++i){
		if(state[i - 1] != 1){
			$(".button" + i).css("background-color", "#383F9F");
			$(".button" + i).click(function(){

				var name = $(this).attr("class");
				name = Number(name.substr(6));//获得序号
				if(state[5] == 0) {
					state[name - 1] = 1;
					deletebutton();
				}
				$(".button" + name).unbind("click");
				
				var child = $(this).children("span");
				child.css("opacity","1");
				child.text("...");

				if(request != null && state[5] == 0) request.abort(); 
				request = $.get("/",function(data){
						$(".button" + name).css("background-color", "#8E8E8E")
						child.text(data);
						if(state[5] == 0) restartbutton();
						else{
							state[name - 1] = 1;
						}
						digbobJudge();
						
		  		});
			});

		}
	}
}


function digbobJudge(){
	var flag = 1;
	for(var i = 0; i < 5; ++i){
		if(state[i] == 0) flag = 0;
	}
	if(flag){
		startBig();
		$("#info-bar").click();
	}
}

function startBig(){
	$("#info-bar").css("background-color", "#383F9F").click(function(){
		var sum = 0;
		for(var i = 1; i <= 5; ++i){
			sum += Number($(".button" + i).children("span").text());
		}
		$("#sum").text(sum);
		$("#info-bar").css("background-color", "#8E8E8E").unbind("click");
	});
}




