
var state = new Array(0,0,0,0,0,0);
var arr = null;
var request;

$(document).ready(function(){

	$("#button").hover(function(){

		$(".message").text("").css("opacity","0");
		for(var i = 0; i <= 5; ++i){
			state[i] = 0;
		}
		$("#mes").text("");
		arr = null;
		if(request != null) request.abort(); 
		$("#info-bar").css("background-color", "#8E8E8E").unbind("click");
		$("#sum").text("");
		deletebutton();
		restartbutton();
		buttonclick();
	});



});

function buttonclick(){
	$(".apb").click(function(){
		if(arr === null) {
			arr = getarray();
			var order = "";
			for(var j = 0; j < 5; ++j){
				switch(arr[j]){
					case 1: order += "A";
					break;
					case 2: order += "B";
					break;
					case 3: order += "C";
					break;
					case 4: order += "D";
					break;
					default:
						order += "E";
				}
			}
			$("#mes").text(order);
		}
		var flag = 1;
		for(var i = 0; i < 5; ++i){
			if(state[arr[i] - 1] == 0){
				$(".button" + arr[i]).click();
				state[5] = 1;
				flag = 0;
				break;
			}
		}
		if(flag) $("#info-bar").click().unbind("click");


	});

}


function deletebutton(){
	for(var i = 1; i <= 5; ++i){
		if(state[i - 1] != 1){
			$(".button" + i).css("background-color", "#8E8E8E").unbind("click");

		}
	}
}

function restartbutton(){
	for(var i = 1; i <= 5; ++i){
		if(state[i - 1] != 1){
			$(".button" + i).css("background-color", "#383F9F");
			$(".button" + i).click(function(){

				var name = $(this).attr("class");
				name = Number(name.substr(6));
				state[name - 1] = 1;
				deletebutton();
				$(".button" + name).unbind("click");
				var child = $(this).children("span");
				child.css("opacity","1");
				child.text("...");

				if(request != null) request.abort(); 
				request = $.get("/",function(data){
						$(".button" + name).css("background-color", "#8E8E8E")
						child.text(data);
						restartbutton();
						digbobJudge();
						if(state[5] == 1){
							$(".apb").click();
						}
		  		});
			});

		}
	}
}


function digbobJudge(){
	var flag = 1;
	for(var i = 0; i < 5; ++i){
		if(state[i] == 0) flag = 0;
	}
	if(flag){
		startBig();
	}
}

function startBig(){
	$("#info-bar").css("background-color", "#383F9F").click(function(){
		var sum = 0;
		for(var i = 1; i <= 5; ++i){
			sum += Number($(".button" + i).children("span").text());
		}
		$("#sum").text(sum);
		$("#info-bar").css("background-color", "#8E8E8E").unbind("click");
	});
}

function randomSort(a, b){
    return Math.random() >= 0.5 ? -1 : 1;
}

function getarray(){
    var arr = [1,2,3,4,5];
    arr.sort(randomSort);
    return arr;
}


