
function MyError(message, currentsum) {  
        this.message = message;  
        this.currentsum = currentsum;  
        this.stack = (new Error()).stack;  
    }  
    MyError.prototype = Object.create(Error.prototype);  
    MyError.prototype.constructor = MyError;  




$(document).ready(function(){

	$("#button").hover(function(){
		$(".message").text("").css("opacity","0");
		stop();

		$("#info-bar").css("background-color", "#8E8E8E");
		$("#sum").text("");
		$("#mes").text("");

		restartbutton();
	});

	



});

function stop(){
	if(stop.prototype.req != null) stop.prototype.req.abort();
}

function deletebutton(arr, i){
	for(i = i + 1; i < 5; ++i){
		$(".button" + arr[i]).css("background-color", "#8E8E8E");
	}
}

function reset(arr, i){
	for(i = i + 1; i < 5; ++i){
		$(".button" + arr[i]).css("background-color", "#383F9F");
	}
}

function restartbutton(){
	$(".apb").unbind("click").click(function(){
		$(this).unbind("click");
		var arr = getarray();
		clickbotton(arr, 0, 0);
	});
	for(var i = 1; i <= 5; ++i){
		$(".button" + i).css("background-color", "#383F9F");
	}
}



function clickbotton(arr, i, currentsum){
	switch(arr[i]){
		case 1: buttona(arr, i, currentsum);
		break;
		case 2: buttonb(arr, i, currentsum);
		break;
		case 3: buttonc(arr, i, currentsum);
		break;
		case 4: buttond(arr, i, currentsum);
		break;
		default: buttone(arr, i, currentsum);
	}

}


function buttona(arr, i,currentsum){
	

	var child = $(".button" + arr[i]).children("span");
	child.css("opacity","1");
	child.text("...");
	deletebutton(arr, i);
	stop();
	stop.prototype.req = $.get("/",function(data){
		$(".button" + arr[i]).css("background-color", "#8E8E8E");
		child.text(data);


		try{
			if(randomSort(0,0) > 0){
				throw new MyError("这不是个天大的秘密", currentsum + Number(data));
			}
			else showmessage("这是个天大的秘密");
			reset(arr, i);
			if(i == 4) startBig(currentsum + Number(data));
			else clickbotton(arr,i + 1, currentsum + Number(data));
		}
		catch(e){
			showmessage(e.message);
			reset(arr, i);
			if(i == 4) startBig(e.currentsum);
			else clickbotton(arr,i + 1, e.currentsum);
		}
		
	});
}

function buttonb(arr,i,currentsum){
	

	var child = $(".button" + arr[i]).children("span");
	child.css("opacity","1");
	child.text("...");
	deletebutton(arr, i);

	stop();
	stop.prototype.req = $.get("/",function(data){
		$(".button" + arr[i]).css("background-color", "#8E8E8E");
		child.text(data);

		try{
			if(randomSort(0,0) > 0){
				throw new MyError("我知道", currentsum + Number(data));
			}
			else showmessage("我不知道");

			reset(arr, i);
			if(i == 4) startBig(currentsum + Number(data));
			else clickbotton(arr,i + 1, currentsum + Number(data));
		}
		catch(e){
			showmessage(e.message);
			reset(arr, i);
			if(i == 4) startBig(e.currentsum);
			else clickbotton(arr,i + 1, e.currentsum);
		}
		
	});

}

function buttonc(arr,i,currentsum){
	
	var child = $(".button" + arr[i]).children("span");
	child.css("opacity","1");
	child.text("...");
	deletebutton(arr, i);

	stop();
	stop.prototype.req = $.get("/",function(data){
		$(".button" + arr[i]).css("background-color", "#8E8E8E");
		child.text(data);
		try{
			if(randomSort(0,0) > 0){
				throw new MyError("你知道", currentsum + Number(data));
			}
			else showmessage("你不知道");
			reset(arr, i);
			if(i == 4) startBig(currentsum + Number(data));
			else clickbotton(arr,i + 1, currentsum + Number(data));
		}
		catch(e){
			showmessage(e.message);
			reset(arr, i);
			if(i == 4) startBig(e.currentsum);
			else clickbotton(arr,i + 1, e.currentsum);
		}
		
	});
}

function buttond(arr,i,currentsum){
	

	var child = $(".button" + arr[i]).children("span");
	child.css("opacity","1");
	child.text("...");
	deletebutton(arr, i);

	stop();
	stop.prototype.req = $.get("/",function(data){
		$(".button" + arr[i]).css("background-color", "#8E8E8E");
		child.text(data);


		try{
			if(randomSort(0,0) > 0){
				throw new MyError("他知道", currentsum + Number(data));
			}
			else showmessage("他不知道");
			reset(arr, i);
			if(i == 4) startBig(currentsum + Number(data));
			else clickbotton(arr,i + 1, currentsum + Number(data));
		}
		catch(e){
			showmessage(e.message);
			reset(arr, i);
			if(i == 4) startBig(e.currentsum);
			else clickbotton(arr,i + 1, e.currentsum);
		}
		
	});
}

function buttone(arr,i,currentsum){
	

	var child = $(".button" + arr[i]).children("span");
	child.css("opacity","1");
	child.text("...");
	deletebutton(arr, i);
	stop();
	stop.prototype.req = $.get("/",function(data){
		$(".button" + arr[i]).css("background-color", "#8E8E8E");
		child.text(data);

		try{
			if(randomSort(0,0) > 0){
				throw new MyError("不怪", currentsum + Number(data));
			}
			else showmessage("才怪");
			reset(arr, i);
			if(i == 4) startBig(currentsum + Number(data));
			else clickbotton(arr,i + 1, currentsum + Number(data));
		}
		catch(e){
			showmessage(e.message);
			reset(arr, i);
			if(i == 4) startBig(Number(e.currentsum));
			else clickbotton(arr,i + 1, e.currentsum);
		}
		
	});
}


function showmessage(message){
	$("#mes").text(message);
}


function startBig(num){
	$("#info-bar").css("background-color", "#383F9F");

	
	$("#sum").text("楼主异步调用战斗力感人，目测不超过" + num);
	
}




function randomSort(a, b){
    return Math.random() >= 0.5 ? -1 : 1;
}

function getarray(){
    var arr = [1,2,3,4,5];
    arr.sort(randomSort);
    return arr;
}


