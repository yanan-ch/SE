$(function() {
	$('.num').hide();
	$('.button.blue').bind('click', buttonclick);
	$('#info-bar').bind('click', infobarclick);
	$('#apb').bind('mouseout', buttonmouseout).bind('click', apbclick);
});

var buttonclick = function() {
	click($(this), false);
}

var click = function(it, auto, arr, index) {
	if (!it.hasClass('blue')) {
		if (auto) {
			return autoclick(arr, index+1);
		} else {
			return;
		}
	}
	it.find('.num').text('...').fadeIn();
	it.attr('title', 'waiting');
	$(".button[title='uninit']").removeClass('blue').addClass('grey');
	$.get('/', function(data) {
		it.find('.num').text(data);
		it.removeClass('blue').addClass('grey');
		it.attr('title', 'done');
		$(".button[title='uninit']").removeClass('grey').addClass('blue');
		if ($('.button.grey').length == 5) {
			$('#info-bar').removeClass('grey').addClass('blue');
			if (auto)
				$('#info-bar').click();
		}
		if (auto) {
			autoclick(arr, index+1);
		}
	});
}

var infobarclick = function() {
	if (!$(this).hasClass('blue')) {
		return;
	}
	var ans = 0;
	$('.num').each(function() {
		ans += parseInt($(this).text());
	});
	$(this).text(ans).removeClass('blue').addClass('grey');
}

var buttonmouseout = function() {
	$('.num').each(function(){
		$(this).text('').fadeOut();
	});
	$('.button.grey').each(function(){
		$(this).removeClass('grey').addClass('blue').attr('title', 'uninit');
	})
	$('#info-bar').text('').removeClass('blue').addClass('grey');
	$('#screen').text('');
}

var apbclick = function() {
	var adders = $('.button.blue');
	adders.sort(function(){
		return Math.random()-0.5;
	});
	var html = '';
	adders.each(function(){
		html += this.id;
	});
	$('#screen').text(html);
	autoclick(adders, 0);
}

var autoclick = function(arr, index) {
	if (index < arr.length)
		click($(arr[index]), true, arr, index);
}
