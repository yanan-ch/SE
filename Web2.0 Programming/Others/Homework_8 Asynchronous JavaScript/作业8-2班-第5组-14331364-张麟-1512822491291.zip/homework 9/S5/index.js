$(function() {
	$('.num').hide();
	$('.button.blue').bind('click', priorityhandler);
	$('#info-bar').bind('click', bubblehandler);
	$('#apb').bind('mouseout', buttonmouseout).bind('click', apbclick);
});

var priorityhandler = function() {
	switch (this.id) {
		case 'A':
			Ahandler($(this), false, 0);
			break;
		case 'B':
			Bhandler($(this), false, 0);
			break;
		case 'C':
			Chandler($(this), false, 0);
			break;
		case 'D':
			Dhandler($(this), false, 0);
			break;
		case 'E':
			Ehandler($(this), false, 0);
			break;
	}
}

var commonjudge = function(it, auto, sum, arr, index) {
	if (!it.hasClass('blue')) {
		if (auto) {
			autoclick(arr, index+1, sum);
		}
		return false;
	}
	it.find('.num').text('...').fadeIn();
	it.attr('title', 'waiting');
	$(".button[title='uninit']").removeClass('blue').addClass('grey');
	return true;
}

var commonsuccesshandler = function(it, data, auto, sum, arr, index) {
	it.find('.num').text(data);
	it.removeClass('blue').addClass('grey');
	it.attr('title', 'done');
	$(".button[title='uninit']").removeClass('grey').addClass('blue');
	if ($('.button.grey').length == 5) {
		$('#info-bar').removeClass('grey').addClass('blue');
		if (auto) {
			bubbleclick(auto, sum+parseInt(data));
		}
	}
	if (auto) {
		autoclick(arr, index+1, sum+parseInt(data));
	}
}

var commonfailhandler = function(it) {
	it.find('.num').fadeOut();
	it.attr('title', 'uninit');
	$(".button[title='uninit']").removeClass('grey').addClass('blue');
}

var Ahandler = function(it, auto, sum, arr, index) {
	if (!commonjudge(it, auto, sum, arr, index))
		return;
	$.ajax({
		url: '/',
		success: function(data) {
			$('#screen').text('这是一个天大的秘密');
			commonsuccesshandler(it, data, auto, sum, arr, index);
		},
		error: function(jqxhr) {
			commonfailhandler(it);
			return {message: '这不是一个天大的秘密', currentSum: sum};
		}
	});
}

var Bhandler = function(it, auto, sum, arr, index) {
	if (!commonjudge(it, auto, sum, arr, index))
		return;
	$.ajax({
		url: '/',
		success: function(data) {
			$('#screen').text('我不知道');
			commonsuccesshandler(it, data, auto, sum, arr, index);
		},
		error: function(jqxhr) {
			commonfailhandler(it);
			return {message: '我知道', currentSum: sum};
		}
	});
}

var Chandler = function(it, auto, sum, arr, index) {
	if (!commonjudge(it, auto, sum, arr, index))
		return;
	$.ajax({
		url: '/',
		success: function(data) {
			$('#screen').text('你不知道');
			commonsuccesshandler(it, data, auto, sum, arr, index);
		},
		error: function(jqxhr) {
			commonfailhandler(it);
			return {message: '你知道', currentSum: sum};
		}
	});
}

var Dhandler = function(it, auto, sum, arr, index) {
	if (!commonjudge(it, auto, sum, arr, index))
		return;
	$.ajax({
		url: '/',
		success: function(data) {
			$('#screen').text('他不知道');
			commonsuccesshandler(it, data, auto, sum, arr, index);
		},
		error: function(jqxhr) {
			commonfailhandler(it);
			return {message: '他知道', currentSum: sum};
		}
	});
}

var Ehandler = function(it, auto, sum, arr, index) {
	if (!commonjudge(it, auto, sum, arr, index))
		return;
	$.ajax({
		url: '/',
		success: function(data) {
			$('#screen').text('才怪');
			commonsuccesshandler(it, data, auto, sum, arr, index);
		},
		error: function(jqxhr) {
			commonfailhandler(it);
			return {message: '不怪', currentSum: sum};
		}
	});
}

var bubblehandler = function() {
	bubbleclick(false);
}

var bubbleclick = function(auto, sum) {
	if (!$('#info-bar').hasClass('blue')) {
		return;
	}
	var ans = 0;
	if (auto) {
		ans = sum;
	} else {
		$('.num').each(function() {
			ans += parseInt($(this).text());
		});
	}
	$('#info-bar').text(ans).removeClass('blue').addClass('grey');
	console.log(auto);
	if (auto) {
		$('#screen').text('楼主异步调用战斗力感人，目测不超过'+ans);
	}
}

var buttonmouseout = function() {
	$('.num').each(function(){
		$(this).text('').fadeOut();
	});
	$('.button.grey').each(function(){
		$(this).removeClass('grey').addClass('blue').attr('title', 'uninit');
	})
	$('#info-bar').text('').removeClass('blue').addClass('grey');
	$('#screen').text('');
	$('#screen2').text('');
}

var autoclick = function(arr, index, sum) {
	if (index >= arr.length)
		return;
	switch (arr[index].id) {
		case 'A':
			Ahandler($(arr[index]), true, sum, arr, index);
			break;
		case 'B':
			Bhandler($(arr[index]), true, sum, arr, index);
			break;
		case 'C':
			Chandler($(arr[index]), true, sum, arr, index);
			break;
		case 'D':
			Dhandler($(arr[index]), true, sum, arr, index);
			break;
		case 'E':
			Ehandler($(arr[index]), true, sum, arr, index);
			break;
	}
}

var apbclick = function() {
	var adders = $('.button.blue');
	adders.sort(function(){
		return Math.random()-0.5;
	});
	var html = '';
	adders.each(function(){
		html += this.id;
	});
	$('#screen2').text(html);
	autoclick(adders, 0, 0);
}
