$(function() {
	$('.num').hide();
	$('.button.blue').bind('click', buttonclick);
	$('#info-bar').bind('click', infobarclick);
	$('#apb').bind('mouseout', buttonmouseout).bind('click', apbclick);
});

var buttonclick = function() {
	click($(this), false);
}

var click = function(it, auto) {
	if (!it.hasClass('blue')) {
		if (auto) {
			return autoclick(it);
		} else {
			return;
		}
	}
	it.find('.num').text('...').fadeIn();
	it.attr('title', 'waiting');
	$(".button[title='uninit']").removeClass('blue').addClass('grey');
	$.get('/', function(data) {
		it.find('.num').text(data);
		it.removeClass('blue').addClass('grey');
		it.attr('title', 'done');
		$(".button[title='uninit']").removeClass('grey').addClass('blue');
		if ($('.button.grey').length == 5) {
			$('#info-bar').removeClass('grey').addClass('blue');
			if (auto)
				$('#info-bar').click();
		}
		if (auto) {
			autoclick(it);
		}
	});
}

var autoclick = function(it) {
	if (it.next().hasClass('button'))
		click(it.next(), true);
}

var infobarclick = function() {
	if (!$(this).hasClass('blue')) {
		return;
	}
	var ans = 0;
	$('.num').each(function() {
		ans += parseInt($(this).text());
	});
	$(this).text(ans).removeClass('blue').addClass('grey');
}

var buttonmouseout = function() {
	$('.num').each(function(){
		$(this).text('').fadeOut();
	});
	$('.button.grey').each(function(){
		$(this).removeClass('grey').addClass('blue').attr('title', 'uninit');
	})
	$('#info-bar').text('').removeClass('blue').addClass('grey');
}

var apbclick = function() {
	click($('#A'), true);
}
