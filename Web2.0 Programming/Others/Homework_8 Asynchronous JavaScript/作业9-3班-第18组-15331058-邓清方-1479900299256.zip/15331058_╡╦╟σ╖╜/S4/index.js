﻿// S5
$(document).ready(function () {
    function toggleButtons(n) {
        $(".button").each(function (i, obj) {
            if (!isNaN(parseInt($(obj).find(".unread").text()))) $(this).addClass("disabled");
            else if (i != n) $(this).toggleClass("disabled");
        });
    }
    function isAllNumGenerated() {
        var flag = true;
        $(".unread").each(function () {
            if (isNaN(parseInt($(this).text()))) flag = false;
        });
        return flag;
    }

    function clickHandler(i, obj) {
        if ($(obj).hasClass("disabled") || $(obj).find(".unread").removeClass("disabled").text() === "…") return false;
        toggleButtons(i);
        $(obj).find(".unread").removeClass("disabled").text("…");
        req = $.ajax({
            type: "GET",
            url: "/",
            success: function (data, status) {
                $(obj).find(".unread").text(data);
                toggleButtons(i);
                if (isAllNumGenerated()) $(".info").removeClass("disabled");
            }
        });
        return req;
    }
    
    $(".button").each(function (i, obj) {
        $(this).on("click", function () { clickHandler(i, obj) });
    });

    $(".info").click(function () {
        if ($(this).hasClass("disabled")) return false;
        var sum = 0;
        $(".unread").each(function () {
            sum += parseInt($(this).text()) || 0;
        });
        $("#sum").text(sum);
        $(this).addClass("disabled");
    });
    $("#button").mouseleave(function () {
        if (typeof (req) != "undefined") req.abort();
        $(".button").each(function (i, obj) {
            $(obj).removeClass("disabled").find(".unread").text("").addClass("disabled");
        });
        $(".info").addClass("disabled");
        $("#sum").text("");
        $("#seq").text("\xa0");
    });

    $(".apb").on("click", function () {
        var array = [0, 1, 2, 3, 4];
        for (var i = array.length - 1; i > 0; i--) {
            var j = Math.floor(Math.random() * (i + 1));
            var temp = array[i];
            array[i] = array[j];
            array[j] = temp;
        }
        const alpha = ["A", "B", "C", "D", "E"];
        var seq = alpha[array[0]];
        for (var i = 1; i < 5; i++) {
            seq += ", " + alpha[array[i]];
        }
        $("#seq").text(seq);
        $.when(clickHandler(array[0], $(buttons[array[0]])).done(function(){
            $.when(clickHandler(array[1], $(buttons[array[1]])).done(function () {
                $.when(clickHandler(array[2], $(buttons[array[2]])).done(function () {
                    $.when(clickHandler(array[3], $(buttons[array[3]])).done(function () {
                        $.when(clickHandler(array[4], $(buttons[array[4]])).done(function () {
                            $(".info").trigger("click");
                        }));
                    }));
                }));
            }));
        }));
    });
});