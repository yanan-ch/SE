﻿// S1
$(document).ready(function () {
    var buttons = $(".button");
    function toggleButtons(n) {
        buttons.each(function (i, obj) {
            if (!isNaN(parseInt($(obj).find(".unread").text()))) $(this).addClass("disabled");
            else if (i != n) $(this).toggleClass("disabled");
        });
    }
    function isAllNumGenerated() {
        var flag = true;
        $(".unread").each(function () {
            if (isNaN(parseInt($(this).text()))) flag = false;
        });
        return flag;
    }

    function clickHandler(i, obj) {
        if ($(obj).hasClass("disabled") || $(obj).find(".unread").removeClass("disabled").text() === "…") return false;
        toggleButtons(i);
        $(obj).find(".unread").removeClass("disabled").text("…");
        req = $.ajax({
            type: "GET",
            url: "/",
            success: function (data, status) {
                $(obj).find(".unread").text(data);
                toggleButtons(i);
                if (isAllNumGenerated()) $(".info").removeClass("disabled");
            }
        });
        return req;
    }

    buttons.each(function (i, obj) {
        $(this).on("click", function () { clickHandler(i, obj) });
    });

    $(".info").click(function () {
        if ($(this).hasClass("disabled")) return false;
        var sum = 0;
        $(".unread").each(function () {
            sum += parseInt($(this).text()) || 0;
        });
        $("#sum").text(sum);
        $(this).addClass("disabled");
    });
    $("#button").mouseleave(function () {
        if (typeof (req) != "undefined") req.abort();
        buttons.each(function (i, obj) {
            $(obj).removeClass("disabled").find(".unread").text("").addClass("disabled");
        });
        $(".info").addClass("disabled");
        $("#sum").text("");
    });
});