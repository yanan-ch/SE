window.onload = function(){
	$(document).ready(function(){

		var d1 = $.Deferred();
		var d2 = $.Deferred();
		var d3 = $.Deferred();
		var d4 = $.Deferred();
		var d5 = $.Deferred();

		$(".A").click(function(){
			AGet(d1, function(){});
		});
		$(".B").click(function(){
			BGet(d2, function(){});
		});
		$(".C").click(function(){
			CGet(d3, function(){});
		});
		$(".D").click(function(){
			DGet(d4, function(){});
		});
		$(".E").click(function(){
			EGet(d5, function(){});
		});

		$.when(d1, d2, d3, d4, d5).done(function(){
			able($(".info"));
		});

		$(".info").click(function(){
			Add($(".A"), $(".B"), $(".C"), $(".D"), $(".E"));
			disable($(".info"));
		});

		$(".apb").click(function(){
			begin(AGet, BGet, CGet, DGet, EGet);
			disable($(".apb"));
		});

		function begin(cbA, cbB, cbC, cbD, cbE){

			var d1 = $.Deferred();
			var d2 = $.Deferred();
			var d3 = $.Deferred();
			var d4 = $.Deferred();
			var d5 = $.Deferred();

			cbA(d1, function(){
				cbB(d2, function(){
					cbC(d3, function(){
						cbD(d4, function(){
							cbE(d5, function(){

							});
						});
					});
				});
			});

			$.when(d1, d2, d3, d4, d5).done(function(){
				infoGet();
			});

		}

		$("#bottom-positioner").mouseleave(reset);

		disable($(".info"));

		function Add(a, b, c, d, e){
			var sum = read(a) + read(b) + read(c) + read(d) + read(e);
			$(".info").html(sum);
		}

		function read(btn){
			var btnHtml = btn.children(".ran_num").html();
			return parseInt(btnHtml);
		}

		function check(btn, func){
			var btnHtml = btn.children(".ran_num").html();
			if(btnHtml == "..."){
				func(btn);
			}
		}

		function check_num(btn){
			return btn.children(".ran_num").html() != "...";
		}

		function disableOther(btn){
			if(btn != $(".A")) disable($(".A"));
			if(btn != $(".B")) disable($(".B"));
			if(btn != $(".C")) disable($(".C"));
			if(btn != $(".D")) disable($(".D"));
			if(btn != $(".E")) disable($(".E"));
		}

		function enableOther(){
		  check($(".A"), able );
		  check($(".B"), able );
		  check($(".C"), able );
		  check($(".D"), able );
		  check($(".E"), able );
		}

		function enableInfo(){
			if(check_num($(".A")) && check_num($(".B")) && check_num($(".C")) 
				&& check_num($(".D")) && check_num($(".E"))){
				able($(".info"));
			}
		}

		function Add(){
			var sum = 0;
			sum = parseInt($(".A").children(".ran_num").html()) + parseInt($(".B").children(".ran_num").html()) +
				parseInt($(".C").children(".ran_num").html()) + parseInt($(".D").children(".ran_num").html()) + 
				parseInt($(".E").children(".ran_num").html());
			$(".info").html(sum);
		}
		
		function disable(btn){
			btn.attr({disabled: "disabled"});
			btn.addClass("disabled");
		}
		function able(btn){
			btn.removeAttr("disabled");
			btn.removeClass("disabled");
		}

		function infoGet(){
			
			Add($(".A"), $(".B"), $(".C"), $(".D"), $(".E"));
			disable($(".info"));
			$(".info").addClass("disabled");
		}

		function AGet(d, func){
			$.ajax({
				type: "post",
				url: "handleAjax",
				
				contentType: "text/plain",
				beforeSend: function(){
					$(".A").children(".ran_num").html("...");
					$(".A").children(".ran_num").addClass("show");
					disableOther($(".A"));
					$(".A").removeClass("disabled");
				},
				success: function(data){
					$(".A").children(".ran_num").html(data);
					enableOther();
					enableInfo();
					$(".A").addClass("disabled");
					d.resolve();
					func();
				},
				error: function(error){
					alert("error: " + error);
				}
			});	

			

		}

		function BGet(d, func){
			$.ajax({
				type: "post",
				url: "handleAjax",
				
				contentType: "text/plain",
				beforeSend: function(){
					$(".B").children(".ran_num").html("...");
					$(".B").children(".ran_num").addClass("show");
					disableOther($(".B"));
					$(".B").removeClass("disabled");

				},
				success: function(data){
					$(".B").children(".ran_num").html(data);
					enableOther();
					enableInfo();
					d.resolve();
					$(".B").addClass("disabled");
					func();
				},
				error: function(error){
					alert("error: " + error);
				}
			});		

		}

		function CGet(d, func){
			$.ajax({
				type: "post",
				url: "handleAjax",
				
				contentType: "text/plain",
				beforeSend: function(){
					$(".C").children(".ran_num").html("...");
					$(".C").children(".ran_num").addClass("show");
					disableOther($(".C"));
					$(".C").removeClass("disabled");

				},
				success: function(data){
					$(".C").children(".ran_num").html(data);
					enableOther();
					enableInfo();
					d.resolve();
					$(".C").addClass("disabled");
					func();
				},
				error: function(error){
					alert("error: " + error);
				}
			});			
		}

		function DGet(d, func){
			$.ajax({
				type: "post",
				url: "handleAjax",
				
				contentType: "text/plain",
				beforeSend: function(){
					$(".D").children(".ran_num").html("...");
					$(".D").children(".ran_num").addClass("show");
					disableOther($(".D"));
					$(".D").removeClass("disabled");

				},
				success: function(data){
					$(".D").children(".ran_num").html(data);
					enableOther();
					enableInfo();
					d.resolve();
					$(".D").addClass("disabled");
					func();
				},
				error: function(error){
					alert("error: " + error);
				}
			});			

		}

		function EGet(d, func){
			$.ajax({
				type: "post",
				url: "handleAjax",
				
				contentType: "text/plain",
				beforeSend: function(){
					$(".E").children(".ran_num").html("...");
					$(".E").children(".ran_num").addClass("show");
					disableOther($(".E"));
					$(".E").removeClass("disabled");

				},
				success: function(data){
					$(".E").children(".ran_num").html(data);
					enableOther();
					enableInfo();
					d.resolve();
					$(".E").addClass("disabled");
					func();
				},
				error: function(error){
					alert("error: " + error);
				}
			});		

		}

		function reset(){
			setTimeout(function(){
				able($(".A"));
				$(".A").children(".ran_num").removeClass("show");
				$(".A").children(".ran_num").html("...");
				able($(".B"));
				$(".B").children(".ran_num").removeClass("show");
				$(".B").children(".ran_num").html("...");
				able($(".C"));
				$(".C").children(".ran_num").removeClass("show");
				$(".C").children(".ran_num").html("...");
				able($(".D"));
				$(".D").children(".ran_num").removeClass("show");
				$(".D").children(".ran_num").html("...");
				able($(".E"));
				$(".E").children(".ran_num").removeClass("show");
				$(".E").children(".ran_num").html("...");

				$(".info").html("");
			}, 1000);

			able($(".apb"));

		}

		

		
	});
}

