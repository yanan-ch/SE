var time = document.getElementById('_time');
var map = document.getElementById('map');
map.addEventListener('click', hit);

window.onload = function (){
  createHole();
}

function hit(event) {
  if (document.getElementById('state').value == "Playing") {
  var scoreNow = document.getElementById('_score');
  if (event.target.className == 'hit_hole') {
    scoreNow.value++;
    event.target.className = 'hole';
    var holes = document.getElementsByTagName('li');
    holes[Math.floor(Math.random()*60)].className = 'hit_hole';
  }
  else {
    if (scoreNow.value == 0) {
      endGame();
    }
    else {
      scoreNow.value--;
    }
  }
}
}

function createHole() {
  var map = document.getElementById('map');
  for (var num = 0; num < 60; ++num) {
    var hole = document.createElement('li');
    hole.className = 'hole';
    map.appendChild(hole);
  }
}

function startEnd() {
  var state = document.getElementById('state');
  if (state.value == 'Game Over') {
    var holes = document.getElementsByTagName('li');
    holes[Math.floor(Math.random()*60)].className = 'hit_hole';
    var state = document.getElementById('state');
    state.value = 'Playing';
    timeCount();
  }
  else {
    endGame();
  }
}

function timeCount() {
    ID = window.setInterval(function() {
      time.value--;
      if (time.value == 0) {
        clearInterval(ID);
        endGame();
      }
    }, 1000);
}

function endGame() {
  var score = document.getElementById('_score').value;
  document.getElementById('state').value = 'Game Over';
  alert("Game Over\nYour score is " + score);
  clearHole();
  clearInterval(ID);
  document.getElementById('_time').value = 30;
}

function clearHole() {
  var holes = document.getElementsByTagName('li');
  for (var a = 0; a < 60; ++a) {
    holes[a].className = 'hole';
  }
}
