var onValid = false;
var start = false;
var knockWall = false;
var container = document.getElementById('container');
var validBlock = document.getElementById('validBlock');
container.addEventListener('mouseover', judgeA);
validBlock.addEventListener('mouseout', judgeC);

function judgeA(event) {
  var tar = event.target;
  if (tar.id == 'validBlock') {
    onValid = true;
  }
  else if (tar.className == 'wall') {
    tar.style.backgroundColor = 'red';
    document.getElementById('message').textContent = 'You lose';
    knockWall = true;
    onValid = false;
    start = false;
  }
  else if (tar.id == 'S') {
    document.getElementById('message').textContent = '';
    start = true;
    knockWall = false;
    onValid = false;
  }

  else if (tar.id != 'validBlock' && tar.className != 'wall' && tar.id != 'E' && tar.id != 'S') {
    onValid = false;
  }

  else if (tar.id == 'E') {
    if (start == true && onValid == true && knockWall == false) {
      document.getElementById('message').textContent = 'You win';
      start = false;
      onValid = false;
    }
    else if (start == false) {
      document.getElementById('message').textContent = 'You should start from S and reach E';
    }
    else if (start == true && onValid == false && knockWall == false) {
      document.getElementById('message').textContent = 'Don\'t cheat, you should start from the "S" and move to the "E" inside the maze!'
      start = false;
    }
  }
}


function judgeC(event) {
  if (event.target.style.backgroundColor == 'red') {
    event.target.style.backgroundColor = '#CCCCCC';
  }
}
