window.onload = function() {
  var map = document.getElementById("moles-map");
  for(var i = 0; i < 60; i++) {
    newmole = document.createElement("button");
    newmole.className = "mole";
    map.appendChild(newmole);
    newmole.onclick = hit;
    newmole.id = i;
  }

  var start = document.getElementById("start");
  var state = document.getElementById("state");
  var moles = document.getElementsByClassName("mole");
  var oldSpan = document.getElementsByTagName("span");

  var timer = null;
  var isStart = false;
  var isStop = false;
  var time = 30;
  var score = 0;
  var current = -1;

  var playingState = document.createTextNode("Playing");
  var stoppingState = document.createTextNode("Stopping");

  function reduce() {
    if(time > 0) {
      time--;
      document.getElementById("time").value = time;
    } else if(time == 0) {
      g_over();
    }
  }

  function hit(e) {
    if(!isStart || isStop) return;
    else {
      var target = e.target;
      if(target.id == current) {
        susliks_appear();
        score++;
      } else {
        score--;
      }
      document.getElementById("score").value = score;
    }
  }

  function dochange(cur) {
    for(var i = 0; i < 60; i++) {
      if(moles[i].id == cur) {
        moles[i].className = "susliks_mole";
        break;
      }
    }
  }

  function restore() {
    document.getElementsByClassName("susliks_mole")[0].className = "mole";
  }

  function susliks_appear() {
    if(current == -1) {
      current = Math.round(Math.random() * 59);
      dochange(current);
    } else {
      restore();
      current = Math.round(Math.random() * 59);
      dochange(current);
    }
  }

  function startOrStop() {
    if(!isStart) {
      isStart = true;
      score = 0;
      time = 30;
      document.getElementById("time").value = time;
      document.getElementById("score").value = score;
      timer = setInterval(reduce, 1000);
      susliks_appear();
      state.replaceChild(playingState, state.firstChild);
    }
    else if(isStop) {
      isStop = false;
      timer = setInterval(reduce, 1000);
      state.replaceChild(playingState, state.firstChild);
    }
    else {
      isStop = true;
      clearInterval(timer);
      timer = null;
      state.replaceChild(stoppingState, state.firstChild);
    }
  }

  function g_over() {
    isStart = false;
    current = -1;
    restore();
    clearInterval(timer);
    alert("Game over.\n" + "You score is:  " + document.getElementById("score").value);
  }

  start.onclick = startOrStop;
}