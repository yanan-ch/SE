window.onload = function() {
  var start = document.getElementById("start");
  var end = document.getElementById("end");
  var result = document.getElementById("result-1");
  var walls = document.getElementsByClassName("walls");
  var passageway = document.getElementById("middle-2");

  var game_start = false;
  var touchWall = false;
  var isCheat = true;
  var target;

  var win = document.createTextNode("You Win");
  var lose = document.createTextNode("You Lose");
  var cheat = document.createTextNode("Don't cheat, you should start from the 'S' and move to the 'E' inside the maze!");

  function display() {
    result.id = "result-2";
  }

  function hide() {
    result.id = "result-1";
  }

  passageway.onmouseover = function() {
    if(game_start) {
      isCheat = false;
    }
  }

  for(var i = 0; i < walls.length; i++) {
    walls[i].onmouseover = dochange;
  }

  function dochange(e) {
    if(game_start && !touchWall) {
      e.target.id += '-touched';
      target = e.target;
      touchWall = true;
      result.replaceChild(lose, result.firstChild);
      display();
    }
  }

  function restore() {
    target.id = target.id.slice(0, -8);
  }

  start.onmouseover = function() {
    hide();
    if(touchWall) restore();
    game_start = true;
    touchWall = false;
    isCheat = true;
  }

  end.onmouseover = function() {
    if(touchWall) {
      result.replaceChild(lose, result.firstChild);
      display();
    }
    else if(isCheat) {
      result.replaceChild(cheat, result.firstChild);
      display();
    }
    else {
      result.replaceChild(win, result.firstChild);
      display();
    }
    game_start = false;
  }
}