window.onload = function() {
  var score = 0;
  var state = "over";
  var currentHole = 0;
  document.getElementsByTagName('input')[0].addEventListener("click",function()
  {
    if(state == "stop")
    {
      if(this.value == "0")
      {
        this.checked = false;
      }
      return;
    }
    if(this.value == 1)
    {
      this.checked = false;
      this.value ="0";
      score +=1;
      document.getElementById('scoreDisplay').innerHTML = score;
      var hole = document.getElementsByTagName('input');
      var  num = Math.floor(Math.random()*60);
      while(num == currentHole)
      {
        num = Math.floor(Math.random()*60);
      }
      currentHole = num;
      hole[num].checked = "true";
      hole[num].value ="1";
    }
    else
    {
      this.checked = false;
      score -=1;
      document.getElementById('scoreDisplay').innerHTML = score;
    }
  });
  for(var i=0;i<59;i++)
  {
    var cNode = document.getElementsByTagName('input')[0].cloneNode(true);
    cNode.addEventListener("click",function(){
      if(state == "stop")
      {
        if(this.value == "0")
        {
          this.checked = false;
        }
        return;
      }
      if(this.value == 1)
      {
        this.checked = false;
        this.value = "0";
        score +=1;
        document.getElementById('scoreDisplay').innerHTML = score;
        var hole = document.getElementsByTagName('input');
        var  num = Math.floor(Math.random()*60);
        while(num == currentHole)
        {
          num = Math.floor(Math.random()*60);
        }
        currentHole = num;
        hole[num].checked = "true";
        hole[num].value ="1";
      }
      else
       {
        this.checked = false;
        score -=1;
        document.getElementById('scoreDisplay').innerHTML = score;
      }
    });
    if(i%10 == 8)
    {
      cNode.style.marginRight = "0px";
    }
    document.getElementById('mole').appendChild(cNode);
  }


  var time = 30;
  document.getElementById('gameControl').onmousedown = function()
  {
    if(event.button == 0)
      document.getElementById('gameControl').style.backgroundColor = "#2991fa";
  }
  document.getElementById('gameControl').onmouseup = function()
  {
      document.getElementById('gameControl').style.backgroundColor = "white";
  }
  document.getElementById('gameControl').onclick = function()
  {
    if(state == "over")
    {
      state = "start";
      document.getElementById('state').innerHTML = "Playing";
      score = 0;
      document.getElementById('scoreDisplay').innerHTML = score;
      document.getElementById('timeDisplay').innerHTML = time;
      a = setInterval(count,1000);
      function count()
      {
        time--;
        document.getElementById('timeDisplay').innerHTML = time;
        if(time == -1)
        {
          document.getElementById('timeDisplay').innerHTML = "0";
          time = 30;
          state = "over";
          document.getElementById('state').innerHTML = "Game over";
          clearInterval(a);
          document.getElementsByTagName('input')[currentHole].value = "0";
          document.getElementsByTagName('input')[currentHole].checked = false;
          alert("Game over.\nYour score is: "+score);
        }
      }
      var hole = document.getElementsByTagName('input');
      var  num = Math.floor(Math.random()*60);
      currentHole = num;
      hole[num].checked = "true";
      hole[num].value = "1";
    }
    else if(state == "stop")
    {
      state = "start";
      document.getElementById('state').innerHTML = "Playing";
      a = setInterval(count,1000);
      function count()
      {
        time--;
        document.getElementById('timeDisplay').innerHTML = time;
        if(time == -1)
        {
          document.getElementById('timeDisplay').innerHTML = "0";
          time = 30;
          state = "over";
          document.getElementById('state').innerHTML = "Game over";
          clearInterval(a);
          document.getElementsByTagName('input')[currentHole].value = "0";
          document.getElementsByTagName('input')[currentHole].checked = false;
          alert("Game over.\nYour score is: "+score);
        }
      }
    }
    else
    {
      state = "stop";
      document.getElementById('state').innerHTML = "Stop";
      clearInterval(a);
    }
  }
}
