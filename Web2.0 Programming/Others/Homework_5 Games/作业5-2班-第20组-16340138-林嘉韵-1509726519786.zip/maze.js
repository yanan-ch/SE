window.onload = function()
{
  var road1 = false;
  var road2 = false;
  var road3 = false;
  var road4 = false;
  var road5 = false;
  var over = true;
  document.getElementById('road_1').onmouseover = function()
  {
    road1 = true;
  }
  document.getElementById('road_2').onmouseover = function()
  {
    road2 = true;
  }
  document.getElementById('road_3').onmouseover = function()
  {
    road3 = true;
  }
  document.getElementById('road_4').onmouseover = function()
  {
    road4 = true;
  }
  document.getElementById('road_5').onmouseover = function()
  {
    road5 = true;
  }
  document.getElementById('start').onmouseover = function()
  {
    road1 = false;
    road2 = false;
    road3 = false;
    road4 = false;
    road5 = false;
    over = false;
    document.body.style.cursor = "pointer";
    document.getElementById('hint').innerHTML = "";
    document.getElementById('wall_4').style.backgroundColor = "#F2F2F2";
    document.getElementById('wall_2').style.backgroundColor = "#F2F2F2";
    document.getElementById('wall_5').style.backgroundColor = "#F2F2F2";
    document.getElementById('wall_6').style.backgroundColor = "#F2F2F2";
    document.getElementById('wall_7').style.backgroundColor = "#F2F2F2";
    document.getElementById('wall_9').style.backgroundColor = "#F2F2F2";
  };
  document.getElementById('end').onmouseover = function()
  {
    if(over)
    {
      return;
    }
    if(road1 && road2 && road3 && road4 && road5)
    {
      document.body.style.cursor = "unset";
      document.getElementById('hint').innerHTML = "You Win";
      over = true;
    }
    else {
      document.getElementById('hint').innerHTML = "Don't cheat, you should start from the 'S' and move to the 'E' inside the maze!";
      over = true;
    }
  }
  document.getElementById('wall_4').onmouseover = function()
  {
    if(over)
    {
      return;
    }
    over = true;
    document.getElementById('wall_4').style.backgroundColor = "red";
    document.getElementById('hint').innerHTML = "You Lose";
  }
  document.getElementById('wall_2').onmouseover = function()
  {
    if(over)
    {
      return;
    }
    over = true;
    document.getElementById('wall_2').style.backgroundColor = "red";
    document.getElementById('hint').innerHTML = "You Lose";
  }
  document.getElementById('wall_5').onmouseover = function()
  {
    if(over)
    {
      return;
    }
    over = true;
    document.getElementById('wall_5').style.backgroundColor = "red";
    document.getElementById('hint').innerHTML = "You Lose";
  }
  document.getElementById('wall_6').onmouseover = function()
  {
    if(over)
    {
      return;
    }
    over = true;
    document.getElementById('wall_6').style.backgroundColor = "red";
    document.getElementById('hint').innerHTML = "You Lose";
  }
  document.getElementById('wall_7').onmouseover = function()
  {
    if(over)
    {
      return;
    }
    over = true;
    document.getElementById('wall_7').style.backgroundColor = "red";
    document.getElementById('hint').innerHTML = "You Lose";
  }
  document.getElementById('wall_9').onmouseover = function()
  {
    if(over)
    {
      return;
    }
    over = true;
    document.getElementById('wall_9').style.backgroundColor = "red";
    document.getElementById('hint').innerHTML = "You Lose";
  }
}
