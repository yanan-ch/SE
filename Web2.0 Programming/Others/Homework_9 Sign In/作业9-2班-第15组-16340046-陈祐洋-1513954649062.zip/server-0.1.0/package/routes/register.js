const express = require('express');
const registerHandler = require('../controller/registerHandler.js');

const router = express.Router();

module.exports = router;

router.get('/', (req, res) => {
    if (req.session.username !== undefined) {
        res.redirect(`../?username=${req.session.username}`);
    }
    res.render('register');
});
router.post('/', (req, res) => {
    const dataRecieved = req.body;
    registerHandler(dataRecieved, (checkUnique) => {
        if (checkUnique === undefined) {
            req.session.username = dataRecieved.username;
            res.end();
        } else {
            res.json(checkUnique);
        }
    });
});
