const express = require('express');
const infoHandler = require('../controller/infoHandler.js');

const router = express.Router();

router.get('/', (req, res) => {
    if (req.session.username !== undefined) {
        if (req.session.username === req.query.username) {
            infoHandler(req.session.username, (info) => {
                if (info === undefined) res.render('err');
                else res.render('info', info);
            });
        } else if (req.originalUrl === '/') {
            res.redirect(`/?username=${req.session.username}`);
        } else if (req.query.username === undefined) {
            res.render('error', { message: '无效访问' });
        } else {
            res.redirect(`/?username=${req.session.username}&cheat=true`);
        }
    } else if (req.originalUrl === '/') {
        res.render('index');
    } else {
        res.render('error', { message: '请先登录' });
    }
});

module.exports = router;
