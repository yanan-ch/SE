const express = require('express');

const router = express.Router();
router.get('/validator.js', (req, res, next) => {
    res.sendFile('validator.js', {
        root: 'model/',
    }, (err) => {
        if (err) {
            next(err);
        }
    });
});

module.exports = router;
