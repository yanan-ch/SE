const express = require('express');
const loginHandler = require('../controller/loginHandler.js');

const router = express.Router();

module.exports = router;

router.post('/', (req, res) => {
    if (req.session.username !== undefined) {
        res.redirect(`../?username=${req.session.username}`);
    }
    const dataRecieved = req.body;
    loginHandler(dataRecieved, (result) => {
        if (result.username && result.password) {
            req.session.username = dataRecieved.username;
        }
        res.json(result);
    });
});
