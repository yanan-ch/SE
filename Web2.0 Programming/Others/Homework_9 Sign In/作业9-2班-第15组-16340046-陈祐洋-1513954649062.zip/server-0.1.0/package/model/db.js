const mongojs = require('mongojs');
const encryptor = require('simple-encryptor')('MTGFwcIISgHJhqgaIg8u');
const config = require('../configration.json');

const db = mongojs('localhost:27017/myDB', ['users']);

function dbfind(target) {
    return new Promise((resolve, reject) => {
        db.users.findOne(target, (err, doc) => {
            if (err) reject(err);
            resolve(doc);
        });
    });
}

db.on('error', (err) => {
    throw (err);
});
/**
 * [checkUnique description]
 * @param  {object} data { username:string, id, phone, email }
 * @return {object} { username:bool(isUnique), id, phone, email }
 *
 */
async function checkUnique(data) {
    let result = {};
    await Promise.all([
        dbfind({ username: data.username }),
        dbfind({ id: data.id }),
        dbfind({ phone: data.phone }),
        dbfind({ email: data.email }),
    ]).then((values) => {
        [
            result.username,
            result.id,
            result.phone,
            result.email,
        ] = [
            values[0] === null,
            values[1] === null,
            values[2] === null,
            values[3] === null,
        ];
    });

    return result;
}

/**
 * check user exist and password match
 * @param  {object} data { username:string, password}
 * @return {object} { username: (isCorrect)bool, password: bool }
 */
async function checkLogin(data) {
    let result = {};
    let target = await dbfind({ username: data.username });
    if (target === null) {
        result.username = false;
        return result;
    }
    result.username = true;
    result.password = encryptor.decrypt(target.password) === data.password;
    return result;
}



/**
 * add user into database
 * @param {object} data { username:string, id, phone, email, password }
 */
function addUser(data) {
    let user = data;
    user.password = encryptor.encrypt(data.password);
    db.users.insert(user, (err) => {});
}

async function getUserInfo(username) {
    let target = await dbfind({ username });
    if (target === undefined) return undefined;
    target.password = encryptor.decrypt(target.password);

    return target;
}

module.exports.checkUnique = checkUnique;
module.exports.addUser = addUser;
module.exports.checkLogin = checkLogin;
module.exports.getUserInfo = getUserInfo;
