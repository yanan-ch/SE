/**
 * validate daya
 * @param  {object} { username(string), id, phone, email, password }
 * @return {Map} validation result
 * {
   username: {
     valid: true or false,
     message: validation info
   },
   ...
 */
function validator(data) {
    const username = { valid: false };
    const id = { valid: false };
    const phone = { valid: false };
    const email = { valid: false };
    const password = { valid: false };
    const result = new Map();

    if (data.username) {
        if (data.username.match(/[^\w\d]/)) {
            username.message = '只能使用英文字母、数字及下划线';
        } else if (data.username.match(/^[a-zA-Z]/) === null) {
            username.message = '必须以英文字母开头';
        } else if (data.username.length < 6 || data.username.length > 18) {
            username.message = `用户名为6~18位 (${data.username.length})`;
        } else username.valid = true;
        result.set('username', username);
    }

    if (data.id) {
        if (data.id.match(/[^\d]/) !== null) {
            id.message = '只能使用数字';
        } else if (data.id.match(/^0/) !== null) {
            id.message = '不能以0开头';
        } else if (data.id.length !== 8) {
            id.message = `学号为8位 (${data.id.length})`;
        } else id.valid = true;
        result.set('id', id);
    }

    if (data.phone) {
        if (data.phone.match(/[^\d]/) !== null) {
            phone.message = '只能使用数字';
        } else if (data.phone.match(/^0/) !== null) {
            phone.message = '不能以0开头';
        } else if (data.phone.length !== 11) {
            phone.message = `电话为11位 (${data.phone.length})`;
        } else phone.valid = true;
        result.set('phone', phone);
    }

    if (data.email) {
        if (data.email.match(/^\w+@\w+(\.\w+)+$/) === null) {
            email.message = '邮箱格式有误';
        } else email.valid = true;
        result.set('email', email);
    }

    if (data.password) {
        if (data.password.match(/[^\w-]/)) {
            password.message = '只能使用英文字母、数字、下划线及中划线';
        } else if (data.password.length < 8 || data.password.length > 20) {
            password.message = `密码为8~20位 (${data.password.length})`;
        } else password.valid = true;
        result.set('password', password);
    }
    return result;
}

if (window === undefined) module.exports.validator = validator;
