# Simple Server

## 使用说明

启动你的mongoDB。

打开根目录configration.json设置mongoDB地址以及服务器监端口。
默认为

- localhost:27017/myDB
- 8000


下载依赖

``` sh
$ npm install
```

启动服务器
``` sh
$ npm start
```
