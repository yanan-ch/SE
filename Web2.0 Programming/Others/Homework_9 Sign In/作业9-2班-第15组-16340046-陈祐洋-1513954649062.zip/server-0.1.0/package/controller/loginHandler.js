const db = require('../model/db.js');

/**
 * handle login data
 * @param  {object} { username(string), password }
 * @return {object} { username:bool, password } or none
 */
function loginHandler(data, callback) {
    db.checkLogin(data).then((result) => {
        // well
        callback(result);
    });
}
module.exports = loginHandler;
