const db = require('../model/db.js');

function infoHandler(username, callback) {
    db.getUserInfo(username)
        .then((info) => { callback(info); });
}
module.exports = infoHandler;
