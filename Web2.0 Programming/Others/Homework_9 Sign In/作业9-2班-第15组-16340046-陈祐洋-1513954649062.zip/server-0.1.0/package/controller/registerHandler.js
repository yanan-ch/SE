const db = require('../model/db.js');

/**
 * handle register data
 * @param  {Object} data { username(string), id, phone, email }
 * @return {Object} { username:bool, id, phone, email } or none
 */
function registerHandler(data, callback) {
    const check = Object.assign({}, data);
    delete check.password;
    db.checkUnique(check).then((isUnique) => {
        let flag = true;

        flag =
            isUnique.username &&
            isUnique.id &&
            isUnique.phone &&
            isUnique.email;

        if (flag) {
            db.addUser(data);
            callback();
        } else {
            let result = {
                username: isUnique.username,
                id: isUnique.id,
                phone: isUnique.phone,
                email: isUnique.email,
            };
            callback(result);
        }
    });
}
module.exports = registerHandler;
