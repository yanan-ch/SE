const express = require('express');
const path = require('path');
const favicon = require('serve-favicon');
const logger = require('morgan');
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');
const session = require('express-session');
const index = require('./routes/index');
const model = require('./routes/model');
const register = require('./routes/register');
const login = require('./routes/login');
const logout = require('./routes/logout');
const MongoStore = require('connect-mongo')(session);
const config = require('./configration.json');

const app = express();
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
    secret: '4TwsE0YABkjJfqYuGzIT',
    store: new MongoStore({ url: `mongodb://${config.mongoDB}` }),
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 60000 * 1000 },
}));
app.use('/model', model);
app.use('/regist', register);
app.use('/login', login);
app.use('/logout', logout);
app.use('/', index);

// catch 404 and forward to error handler
app.use((req, res, next) => {
    const err = new Error('Not Found');
    err.status = 404;
    next(err);
});

// error handler
app.use((err, req, res) => {
    // set locals, only providing error in development
    res.locals.message = err.message;
    res.locals.error = req.app.get('env') === 'development' ? err : {};

    // render the error page
    res.status(err.status || 500);
    res.render('error', { message: `错误: ${res.status}` });
});
console.log(`Server listening on port ${config.port}`);

app.listen(config.port);
