window.onload = onLoadHandler;

function onLoadHandler() {
    $('#submit_button').on('click', submit);
    $('#reset_button').on('click', reset);
    $('#main_form input').on('input', valid);
    $(document).on('keydown', (event) => {
        if (event.which === 13 && !$('#submit_button').attr('disabled')) submit();
    })
}

function submit() {
    $.post('/regist', {
        username: $('#username').val(),
        id: $('#id_number').val(),
        phone: $('#phone').val(),
        email: $('#email').val(),
        password: $('#password').val()
    }).done((response) => {
        if (response.username === undefined) {
            window.location.assign(`../?username=${$('#username').val()}`);
        } else {
            let msg = [];
            if (!response.username) msg.push('用户名');
            if (!response.id) msg.push('学号');
            if (!response.phone) msg.push('电话');
            if (!response.email) msg.push('邮箱');
            $('#msg').text(`${msg.join('、')}重复`);
        }
    });
}

function reset() {
    $('#main_form input').each((index, input) => {
        $(input).val('');
    });
    $('.is-dirty').removeClass('is-invalid').removeClass('is-dirty');
    $('#submit_button').attr('disabled', true);
}

function valid() {
    let isValid = true;
    const data = {
        username: $('#username').val(),
        id: $('#id_number').val(),
        phone: $('#phone').val(),
        email: $('#email').val(),
        password: $('#password').val()
    }
    let result = new Map();
    result = validator(data);
    result.forEach((value, key) => {
        let target;
        switch (key) {
            case 'username':
                target = 'username';
                break;
            case 'id':
                target = 'id_number';
                break;
            case 'email':
                target = 'email';
                break;
            case 'phone':
                target = 'phone';
                break;
            case 'password':
                target = 'password';
                break;
            default:
                break;
        }
        target = `#${target}`;
        if (value.valid === false) {
            $(target).next().next().text(value.message);
            isValid = false;
        } else {
            $(target).parent('div').removeClass('is_invalid');
        }
    })


    if ($('#password').val() !== $('#password_repeat').val()) {
        $('#password_repeat').next().next().text('密码不相同');
        isValid = false;
    } else {
        $('#password_repeat').parent('div').removeClass('is-invalid');
    }

    if ($('.is-dirty').length !== $('#main_form input').length) isValid = false;
    if (isValid) {
        $('#submit_button').attr('disabled', false);
    } else {
        $('#submit_button').attr('disabled', true);
    }
}
