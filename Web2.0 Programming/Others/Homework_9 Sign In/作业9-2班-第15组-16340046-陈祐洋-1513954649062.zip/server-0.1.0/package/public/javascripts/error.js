window.onload = onLoadHandler;

function onLoadHandler() {
    $('#login_button').on('click', () => { location.assign('/'); });
    $('#register_button').on('click', () => { location.assign('/regist'); });
}
