window.onload = onLoadHandler;

function onLoadHandler() {
    $('#register_button').on('click', register);
    $('#login_button').on('click', login);
    $('input').on('input', validate);
    $(document).on('keydown', (event) => {
        if (event.which === 13 && !$('#login_button').attr('disabled')) login();
    })
}

function register() {
    location.assign('regist');
}

function validate() {
    let isValid = true;
    const data = {
        username: $('#username').val(),
        password: $('#password').val()
    }
    let result = new Map();
    result = (validator(data)); // Map
    result.forEach((value, key) => {
        const target = `#${key}`;
        if (value.valid === false) {
            $(target).next().next().text(value.message);
            isValid = false;
        } else {
            $(target).parent('div').removeClass('is_invalid');
        }
    })
    if ($('.is-dirty').length !== $('#main_form input').length) isValid = false;
    if (isValid) {
        $('#login_button').attr('disabled', false);
    } else {
        $('#login_button').attr('disabled', true);
    }
}

function login() {
    $.post('/login', {
        username: $('#username').val(),
        password: $('#password').val()
    }).done((response) => {
        if (response.username && response.password) {
            location.assign(`/?username=${$('#username').val()}`);
        } else {
            let message = response.username ? '密码错误' : '用户不存在';
            document.getElementById('message').MaterialSnackbar.showSnackbar({ message });
        }
    });
}
