window.onload = onLoadHandler;

function onLoadHandler() {
    $('#register_button').on('click', logout);
    let params = new URLSearchParams(window.location.search);
    if (params.get('cheat') === 'true') {
        setTimeout(() => {
            document.getElementById('message').MaterialSnackbar.showSnackbar({
                message: '只能访问自己的数据',
                timeout: 10000,
            });
        }, 200);
    }
}

function logout() {
    $.post('/logout').done(() => { location.assign('/'); });
}
