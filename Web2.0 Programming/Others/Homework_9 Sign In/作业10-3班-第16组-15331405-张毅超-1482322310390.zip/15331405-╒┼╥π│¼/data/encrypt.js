/*var jQuery = require('../public/javascripts/jquery.min');
var md5 = require('../public/javascripts/jquery.md5');

module.exports = {
	encrypt: function(password) {
		return _encrypt(password);
	}
};

var _encrypt = function(password) {
	return md5.$.md5(password);
};*/