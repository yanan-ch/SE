var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var models = require('./data');

for (var key in models) {
	mongoose.model(key, new Schema(models[key]));
}

/*module.exports = {
	getUser: function(type) {
		return function() {
			return mongoose.model(type);
		};
	}
};*/

module.exports = {
	getUser: function(type) {
		return _getUser(type);
	}
};

var _getUser = function(type) {
	return mongoose.model(type);
};