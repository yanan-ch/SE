// database
module.exports = {
	user: {
		username: String,
		password: String,
		idnum: String,
		tele: String,
		email: String
	}
};