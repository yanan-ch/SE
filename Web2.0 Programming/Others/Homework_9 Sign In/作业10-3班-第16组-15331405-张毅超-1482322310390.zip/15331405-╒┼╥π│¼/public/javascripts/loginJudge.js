$(function() {
	$('#register').click(function() {
		location.href = 'regist';
	});
});