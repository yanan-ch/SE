$(function() {
	var inputs = $('input');
	inputs.each(function() {
		$(this).parent().find('p').hide();
	});
	for (var i = 0; i < 6; ++i) {
		$(inputs[i]).blur(function() {
			if (Judge[this.id]($(this).val()))
				$(this).parent().find('p').hide();
			else
				$(this).parent().find('p').show();
		});
	}
	$('#submit').click(function() {
		for (var j = 0; j < 6; ++j)
			$(inputs[j]).blur();
		if (!Judge['total']())
			return false;
	});
});
