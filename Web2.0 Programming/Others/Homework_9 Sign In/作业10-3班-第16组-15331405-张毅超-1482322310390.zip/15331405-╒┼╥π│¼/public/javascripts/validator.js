var Judge = {
	state: {
		s1: false,
		s2: false,
		s3: false,
		s4: false,
		s5: false,
		s6: false,
		pw: ''
	},
	username: function(username) {
		Judge['state']['s1'] = /^[a-zA-Z][a-zA-Z0-9_]{6,18}$/.test(username);
		return /^[a-zA-Z][a-zA-Z0-9_]{6,18}$/.test(username);
	},
	password: function(password) {
		Judge['state']['pw'] = password;
		Judge['state']['s5'] = /^[a-zA-Z0-9_\-]{6,12}$/.test(password);
		return /^[a-zA-Z0-9_\-]{6,12}$/.test(password);
	},
	confirm: function(repeatpw) {
		Judge['state']['s6'] = Judge['state']['pw'] === repeatpw;
		return Judge['state']['pw'] === repeatpw;
	},
	idnum: function(idnum) {
		Judge['state']['s2'] = /^[1-9]\d{7}$/.test(idnum);
		return /^[1-9]\d{7}$/.test(idnum);
	},
	tele: function(tele) {
		Judge['state']['s3'] = /^[1-9]\d{10}$/.test(tele);
		return /^[1-9]\d{10}$/.test(tele);
	},
	email: function(email) {
		Judge['state']['s4'] = /^[a-zA-Z_\-]+@(([a-zA-Z_\-])+\.)+[a-zA-Z]{2,4}$/.test(email);
		return /^[a-zA-Z_\-]+@(([a-zA-Z_\-])+\.)+[a-zA-Z]{2,4}$/.test(email);
	},
	total: function() {
		return Judge['state']['s1'] && Judge['state']['s2'] && Judge['state']['s3'] && Judge['state']['s4'] && Judge['state']['s5'] && Judge['state']['s6'];
	}
};
