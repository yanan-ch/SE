var express = require('express');
var session = require('express-session');
var router = express.Router();
var encryption = require('../data/encrypt');

/* GET login page. */
router.get('/', function(req, res, next) {
  if (!req.session.user)
	res.render('login', { title: '用户登录', error: req.session.err});
  else {
	req.session.user = req.session.user;
	res.redirect('/detail');
  }
});

/* POST login message, check it for next step */
router.post('/', function(req, res, next) {
  var users = global.dbmodel.getUser('user');
  var correntUser = req.body;
  /*	// using jquery.md5 to encrypt the password
  correntUser.password = encryption.encrypt(correntUser.password);*/
  users.findOne({username: correntUser.username}, function(error, doc) {
	if (error) {
		console.log(error);
		req.session.err = error;
		res.redirect('/');
	} else if (!doc) {
		req.session.err = '用户名不存在!';
		res.redirect('/');
	} else {
		if (correntUser.password != doc.password) {
			req.session.err = '错误的用户名或者密码!';
			res.redirect('/');
		} else {
			req.session.user = doc;
			res.redirect('/detail');
		}
	}
  });
});

/* GET regist page. */
router.get('/regist', function(req, res, next) {
  if (req.session.register)
    res.render('regist', { title: '用户注册', error: req.session.err, register: req.session.register});
  else
	res.render('regist', { title: '用户注册', error: req.session.err, register: {}});
});

/* POST regist message, check it for next step */
router.post('/regist', function(req, res, next) {
  var users = global.dbmodel.getUser('user');
  var correntUser = req.body;
  /*	// using jquery.md5 to encrypt the password
  correntUser.password = encryption.encrypt(correntUser.password);*/
  users.findOne({username: correntUser.username}, function(error, doc) {
	if (error) {
		console.log(error);
		req.session.err = error;
		req.session.register = {};
		res.redirect('/regist');
	} else if (doc) {
		req.session.err = '用户名已存在!';
		req.session.register = correntUser;
		res.redirect('/regist');
	} else {
		users.create({
			username: correntUser.username,
			password: correntUser.password,
			idnum: correntUser.idnum,
			tele: correntUser.tele,
			email: correntUser.email
		}, function(error, doc) {
			if (error) {
				console.log(error);
				req.session.err = error;
				req.session.register = {};
				res.redirect('/regist');
			} else {
				req.session.user = doc;
				res.redirect('/detail');
			}
		});
	}
  });
});

/* GET detail page. */
router.get('/detail', function(req, res, next) {
  res.render('detail', { title: '用户详情', user: req.session.user});
});

/* POST detail page for logout */
router.post('/detail', function(req, res, next) {
	console.log('test');
	req.session.user = null;
	req.session.err = null;
	res.redirect('/');
});

module.exports = router;
