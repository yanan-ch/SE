#readme

---

###本次实验内容需要:

 1. 提前安装好全局的mongodb，以便储存data数据(db, log);
 2. 如果没有node_modules文件夹，需自行安装在package.json中的依赖关系=>
 "dependencies": {
    "body-parser": "~1.15.2",
    "cookie-parser": "~1.4.3",
    "debug": "~2.2.0",
    "ejs": "~2.5.2",
    "express": "~4.14.0",
    "express-session": "^1.14.2",
    "mongodb": "^2.2.16",
    "mongoose": "^4.7.4",
    "morgan": "~1.7.0",
    "multer": "^0.1.8",
    "serve-favicon": "~2.3.0"
  }
  **其中注意multer的安装应为0.1.8版, 指令为npm install multer@0.1.8 --save**

---

###运行方式:

在根目录下打开cmd, 输入指令 **npm start** 即可
端口在8000, 输入 **localhost:8000** 即可进入登陆界面