1.Please run "mongod --dbpath=./data --port 27017" in the first command shell firstly.
2.Please run "npm start" in the second command shell.