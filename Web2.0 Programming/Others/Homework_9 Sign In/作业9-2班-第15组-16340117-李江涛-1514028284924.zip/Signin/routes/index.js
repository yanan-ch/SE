const express = require('express');
const validator = require('../public/javascripts/validator');
const session = require('express-session');
const url = require("url");
const queryString  = require("querystring");

const router = express.Router();

module.exports = function(db){
	const userManager = require('../models/user')(db);
	/* GET home page. */

	router.get('/', function(req, res, next) {
		if(req.session.user&&req.query.username){
			if(req.query.username==req.session.user.username){		
				res.render('detail',{err:{},user:req.session.user});				
			}
			else {
				res.render('detail',{err:{message:'只能够访问自己的数据'},user:req.session.user});								
			}
		}
		else if(req.query.username){
			res.redirect('/');
		}
		else if(req.session.user) {
			res.redirect('/?username='+req.session.user.username);
	  }
	  else res.render('signin');
	});

	router.post('/signin', async function(req, res, next){
		try{
			var user = await userManager.queryUser(req.body.username,req.body.password);
			if(user) {
				req.session.user=user;
			}
			res.send('');
		}catch(err){
			res.send(err.message);
		}
	});

	router.get('/signout', function(req, res, next){
		req.session.destroy();
		res.redirect('/');
	})

	router.get('/regist', function(req, res, next) {
	  res.render('regist',{user:{}});
	});

	router.post('/regist', async function(req, res, next){
		var user=req.body;
		try{
			checkUser(user);
			await userManager.checkUserIsUnique(user);
			userManager.insertUser(user);
			req.session.user=user;
			res.send('');
		}catch(err){
			res.send(err.message);
		}
		
	});

	return router;
};

function checkUser(user){
	var err='';
  if(!validator.isUsernameValid(user.username)){
  	err+=validator.getErrorMessage('username')+'<br />';
  }
  if(!validator.isNumberValid(user.number)){
  	err+=validator.getErrorMessage('number')+'<br />';
  }
  if(!validator.isPhoneValid(user.phone)){
  	err+=validator.getErrorMessage('phone')+'<br />';
  }
  if(!validator.isEmailValid(user.email)){
  	err+=validator.getErrorMessage('email')+'<br />';
  }
  if(!validator.isPasswordValid(user.password)){
  	err+=validator.getErrorMessage('password')+'<br />';
  }
  if(!validator.isConfirmPasswordValid(user.confirmPassword)){
  	err+=validator.getErrorMessage('confirmPassword');
  }
  if(!validator.isFormValid()){
  	throw new Error(err);
  }
  
}