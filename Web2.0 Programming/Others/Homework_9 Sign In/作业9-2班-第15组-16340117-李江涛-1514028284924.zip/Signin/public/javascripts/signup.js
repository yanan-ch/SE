$(function (){
	$('#register').click(checkUser);
})

function checkUser(){
	var name=$("#username").val();
  var number=$("#number").val();
  var phone=$("#phone").val();
  var email=$("#email").val();
  var password=$("#password").val();
  var confirmPassword=$("#confirmPassword").val();
  var err='';
  if(!validator.isUsernameValid(name)){
  	err+=validator.getErrorMessage('username')+'<br />';
  }
  if(!validator.isNumberValid(number)){
  	err+=validator.getErrorMessage('number')+'<br />';
  }
  if(!validator.isPhoneValid(phone)){
  	err+=validator.getErrorMessage('phone')+'<br />';
  }
  if(!validator.isEmailValid(email)){
  	err+=validator.getErrorMessage('email')+'<br />';
  }
  if(!validator.isPasswordValid(password)){
  	err+=validator.getErrorMessage('password')+'<br />';
  }
  if(!validator.isConfirmPasswordValid(confirmPassword)){
  	err+=validator.getErrorMessage('confirmPassword');
  }
  if(validator.isFormValid()){
  	var user={username:name,number:number,phone:phone,email:email,
  		password:password,confirmPassword:confirmPassword};
  	$.post('http://localhost:8000/regist',user,function(data){
  		if(data){
  			Toast(data);
  		}
  		else{
  			window.location.assign('/?username='+user.username);
  		}
  	});
  }
  else {
  	Toast(err);
  }
}

function Toast(msg,duration){
    duration=isNaN(duration)?3000:duration;
    var m=$('<div></div>');
    m.html(msg);
    m.attr('id','toast');
    m.appendTo('body');
    setTimeout(function() {
        m.fadeOut();
        setTimeout(function(){
          m.remove();
        },1000);
    }, duration);
}