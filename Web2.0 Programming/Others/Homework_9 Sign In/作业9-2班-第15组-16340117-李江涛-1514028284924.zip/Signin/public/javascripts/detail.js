$(function(){	
	$('.btn').click(jumpToSignin);
	runUpWhenErrorComes();
})

function jumpToSignin(){
	window.location.assign('/signout');
}

function runUpWhenErrorComes(){
	id=setInterval(checkError,100);
}

function checkError(){
	if($('#toast').html()){
		$('#toast').show();
		clearInterval(id);
		$('#toast').fadeOut(3000,function(){
			$('#toast').html('');
			runUpWhenErrorComes();
		});
	}
}