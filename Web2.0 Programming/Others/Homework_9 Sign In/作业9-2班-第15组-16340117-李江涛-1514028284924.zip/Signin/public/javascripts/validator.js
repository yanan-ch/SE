var validator = {
	form: {
		username: {
			status: false,
			errorMessage: '用户名6~18位英文字母、数字或下划线，必须以英文字母开头'
		},
		number: {
			status: false,
			errorMessage: '学号8位数字，不能以0开头'
		},
		phone: {
			status: false,
			errorMessage: '电话11位数字，不能以0开头'
		},
		email: {
			status: false,
			errorMessage: '请输入合法邮箱'
		},
		password: {
			status: false,
			errorMessage: '密码为6~12位数字、大小写字母、中划线、下划线'
		},
		confirmPassword: {
			status: false,
			errorMessage: '密码不一致'
		}
	},

	isUsernameValid: function(username){
		return this.form.username.status = /^[a-zA-Z][a-zA-Z0-9_]{6,18}$/.test(username);
	},

	isNumberValid: function(number){
		return this.form.number.status = /^[1-9]\d{7}$/.test(number);
	},

	isPhoneValid: function(phone){
		return this.form.phone.status = /^[1-9]\d{10}$/.test(phone);
	},

	isEmailValid: function(email){
		return this.form.email.status = /^[\w\-]+@(([\w\-])+\.)+[a-zA-Z]{2,4}$/.test(email);
	},

	isPasswordValid: function(password){
		this.password = password;
		return this.form.password.status = /^[0-9a-zA-Z_-]{6,12}$/.test(password);
	},

	isConfirmPasswordValid: function(confirmPassword){
		return this.form.confirmPassword.status = this.password==confirmPassword;
	},

	isFieldValid: function(field,value){
		var fieldName=field[0].toUpperCase()+field.slice(1, field.length);
		return this['is'+fieldName+'Valid'](value);
	},

	isFormValid: function(){
		return this.form.username.status&&this.form.number.status&&this.form.phone.status&&this.form.email.status
		&&this.form.password.status&&this.form.confirmPassword.status;
	},

	getErrorMessage: function(field){
		return this.form[field].errorMessage;
	}
}

if(typeof module == 'object'){
 module.exports = validator;
}