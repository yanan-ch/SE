$(function(){
	$('#register').click(jumpToRegister);
	$('#signinBtn').click(signin);
})

function jumpToRegister(){
	window.location.assign('/regist');
}

function signin(){
	var name=$('#username').val();
	var password=$('#password').val();
	var user={username:name,password:password};
	$.post('http://localhost:8000/signin',user,function(data){
		if(data){
			Toast(data);
		}
		else{
			window.location.assign('/?username='+name);
		}
	});
}

function Toast(msg,duration){
    duration=isNaN(duration)?3000:duration;
    var m=$('<div></div>');
    m.html(msg);
    m.attr('id','toast');
    m.appendTo('body');
    setTimeout(function() {
        m.fadeOut();
        setTimeout(function(){
          m.remove();
        },1000);
    }, duration);
}