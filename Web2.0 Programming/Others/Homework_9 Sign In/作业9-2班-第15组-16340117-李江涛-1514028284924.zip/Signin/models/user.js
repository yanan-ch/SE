const validator = require('../public/javascripts/validator');
const bcrypt = require('bcryptjs');
const salt = bcrypt.genSaltSync(10);

module.exports = function(db){
	var users = db.collection('users');
	return {
		insertUser: function(user){
			var hash = bcrypt.hashSync(user.password, salt);
			user.password=user.confirmPassword=hash;
			users.insert(user);
		},
		queryUser: function(username, password){
			return new Promise(function(resolve,reject){
				var whereStr = {username:username};
				users.find(whereStr).toArray(function(err,data){
					if(data.length!=0&&bcrypt.compareSync(password, data[0].password)) resolve(data[0]);
					else reject(new Error('错误的用户名或者密码'));
				});
			});
		},
		checkUserIsUnique: function(user){
			return new Promise(function(resolve,reject){
				var error='';
				users.find({username:user.username}).toArray(function(err,data){
					if(data.length!=0) error+='用户名重复，请重新输入<br />';
					users.find({number:user.number}).toArray(function(err,data){
						if(data.length!=0) error+='学号重复，请重新输入<br />';
						users.find({phone:user.phone}).toArray(function(err,data){
							if(data.length!=0) error+='电话重复，请重新输入<br />';
							users.find({email:user.email}).toArray(function(err,data){
								if(data.length!=0) error+='邮箱重复，请重新输入<br />';
								if(error) reject(new Error(error));
								else resolve();
							});
						})
					})
				});
			})
		}
		
	}
}