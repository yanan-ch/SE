module.exports = {
  cookieSecret: 'signin',
  db: 'signin',
  host: 'localhost',
  port: 27017,
  url: 'mongodb://localhost:27017/signin'
};