var db = require('./db');

var dataHandler = {
  insert: function(user) {
    return new Promise(function(resolve, reject) {
      // open database
      db.open(function(err, db) {
        if (err) {
          reject(err);
        }
        // find the users collection
        db.collection('users', function(err, users) {
          if (err) {
            db.close();
            reject(err);
          }
          // insert user data to the users collection
          users.insert(user, {safe: true}, function(err, user) {
            db.close();
            if (err) {
              reject(err);
            }
            resolve(user);
          });
        });
      });
    }); 
  },

  getAllUsers: function() {
    return new Promise(function(resolve, reject) {
      // open database
      db.open(function(err, db) {
        if (err) {
          reject(err);
        }
        // find the users collection
        db.collection('users', function(err, users) {
          if (err) {
            db.close();
            reject(err);
          }
          // find all users'data in the users collection
          users.find({}).toArray(function(err, users) {
            db.close();
            if (err) {
              reject(err);
            }
            resolve(users);
          });
        });
      });
    });
  },

  getUserByUsername: function(name) {
    return new Promise(function(resolve, reject) {
      // open database
      db.open(function(err, db) {
        if (err) {
          reject(err);
        }
        // find the users collection
        db.collection('users', function(err, users) {
          if (err) {
            db.close();
            reject(err);
          }
          // find user data in the users collection by username
          users.findOne({username: name}, function(err, user) {
            db.close();
            if (err) {
              reject(err);
            }
            resolve(user);
          });
        });
      });
    });
  }
}

exports.dataHandler = dataHandler;