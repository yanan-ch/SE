var url  = require("url"),
    fs=require("fs"),
    http=require("http"),
    path = require("path");
var querystring = require("querystring");


http.createServer(function (req, res) {
    var pathname = url.parse(req.url).pathname;
    
    if (req.url.indexOf('?') != -1) {

        var place = req.url;
        var data=fs.readFileSync("data.txt","utf-8");  
        
        var _data = data.split('\n');
        var number = 0;
        var gett = -1;
        
        for (var i = 0; i < data.length; i++) {
            if (data[i] == '\n') {number++;}
        }
        for (var i = 0; i < number; i++) {
            if (_data[i].indexOf(place.substr(place.indexOf('?')+1,place.length)) != -1) {gett = i;}
        }
       
       
        
        if (gett != -1) {
            console.log('username is found!')

            var result = querystring.parse(_data[gett],'&','=');
            var file = fs.readFileSync('infomation.html');
            var change = file.toString().split('&');
            change[1] = result.username;
            change[3] = result.xuehao;
            change[5] = result.phone;
            change[7] = result.email;
            var content = "";
            for (var i = 0; i < change.length; i ++)
            content += change[i];
            res.write(content);
        }
        else {
            console.log('username wrong!');
            res.writeHead(200, {"Content-Type": "text/html"});
            fs.readFile(__dirname + pathname + "index.html",function(err,data){
                res.end(data);
            });
        }
    }

    if (pathname == "/") {
        res.writeHead(200, {"Content-Type": "text/html"});
        fs.readFile(__dirname + pathname + "index.html",function(err,data){
            res.end(data);
        });
    }

    else if(pathname == "/postlogin") {

        var urlstr="";
        var same = 1;
        req.addListener("data",function(postdata){
            urlstr+=postdata;   
            var jsondata = querystring.parse(urlstr);        //转换成json对象
            var decodedata = decodeURIComponent(urlstr);        //对表单数据进行解码
            console.log(decodedata);
            urlstr = decodedata;



            var data=fs.readFileSync("data.txt","utf-8");
            var _data = data.split('\n');
            
            var num0 = 0;
            var num1 = 0;
            for (var i = 0; i < _data.length; i++) {
                if (_data[i].username == jsondata.username) {same = 0;num0 = 0;num0 = 0;break;}
                if (_data[i].xuehao == jsondata.xuehao) {same = 0;num0 = 1;num0 = 0;break;}
                if (_data[i].phone == jsondata.phone) {same = 0;num0 = 0;num1 = 1;break;}
                if (_data[i].email == jsondata.email) {same = 0;num0 = 1;num1 = 1;break;}
            }


            if (same == 1) {
             fs.writeFile('./data.txt',urlstr + '\n' , {'flag': 'a' },function(err){
                if (err) {
                    throw err;
                }
                console.log('saved.');
            });
            }
            else {
                console.log('failed.');
                if (num0 == 0&&num1 == 0) {console.log('username has existed')};
                if (num0 == 1&&num1 == 0) {console.log('id has existed')};
                if (num0 == 0&&num1 == 1) {console.log('phone number has existed')};
                if (num0 == 1&&num1 == 1) {console.log('email has existed')};
            }
        });
           
        req.addListener("end",function(){
            var result = querystring.parse(urlstr,'&','=');
            var file = fs.readFileSync('infomation.html');
            var change = file.toString().split('&');
            change[1] = result.username;
            change[3] = result.xuehao;
            change[5] = result.phone;
            change[7] = result.email;
            var content = "";
            for (var i = 0; i < change.length; i ++)
            content += change[i];
            res.write(content);
        });
    }
    else {
        res.writeHead(404, {"Content-Type": "text/html"});
        res.end("<h1>404 Not Found</h1>");
    }

    
}).listen(8000);
console.log("Server running at localhost");