var Validator = {
	form: {
		username: {
			status: false,
			errorMessage: "以英文字母开头，6-18位英文字母、数字或下划线",
		},
		studentNum: {
			status: false,
			errorMessage: "8位数字，0不能为开头",
		},
		phone: {
			status: false,
			errorMessage: "11位数字，0不能为开头",
		},
		email: {
			status: false,
			errorMessage: "请输入合法的邮箱,只能包含字母、@、.、_",
		}
	},

	isValidUsername: function (value){
		this.form.username.status = /^[a-zA-Z][0-9a-zA-Z]{5,17}$/.test(value);
	},
	isValidStudentNum: function (value){
		this.form.studentNum.status = /^[1-9][0-9]{7}$/.test(value);
	},
	isValidPhone: function (value){
		this.form.phone.status = /^[1-9][0-9]{10}$/.test(value);
	},
	isValidEmail: function (value){
		this.form.email.status = /^[a-zA-Z_\-]+@[a-zA-Z_\-]+\.+[a-zA-Z]{2,4}$/.test(value);
	},
};

if(typeof module == "object"){
	module.exports = Validator;
}