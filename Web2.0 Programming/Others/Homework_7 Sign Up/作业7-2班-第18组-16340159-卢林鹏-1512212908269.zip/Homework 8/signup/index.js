var http = require("http");
var url = require("url");
var querystring = require("querystring");
var jade = require("jade");
var fs = require("fs");
var Validator = require("./js/Validator");
var users = {};
http.createServer(function(request,response){
	switch(request.url){
		case "/js/Validator.js":
			sendFile(response, "./js/Validator.js" , "text/javascript");
			break;
		case "/js/signup.js":
			sendFile(response, "./js/signup.js", "text/javascript");
			break;
		case "/css/style.css":
			sendFile(response, "./css/style.css", "text/css");
			break;
		case "/css/detail.css":
			sendFile(response, "./css/detail.css", "text/css");
			break;
		default:
		request.method === "POST" ? UserRegist(request,response) : sendHtml(request,response);
	}
	
}).listen(8080);

console.log("Signup server is listening at 8080");

function sendFile(response, path , type){
	response.writeHead(200,{"Content-Type": type});
	response.write(fs.readFileSync(path));
	response.end();
}



function UserRegist(request,response){
	request.on("data", function(chunk){
		var user = parseUser(chunk.toString());
		var errorMessages = [];
		isUniqueUser(user,errorMessages);
		if(errorMessages.length >= 1){
			var error ="";
			for(var i = 0; i < errorMessages.length; i++)
				error += errorMessages[i] + ' <br />';
			// console.log(new Error(errorMessages.join("<br />")));
			response.writeHead(200,{"Content-Type": "text/html;charset=utf-8"});
			response.write(jade.renderFile("./jade/signup.jade",{user: user,error: errorMessages.join("<br/>")}));
    		response.end();
    		return ;
		}
		users[user.username] = user;
		response.writeHead(301,{Location: "?username=" + user.username});
		response.end();
	});
}
function isUniqueUser(user,errorMessages){
	Validator.isValidUsername(user.username);
	Validator.isValidStudentNum(user.studentNum);
	Validator.isValidPhone(user.phone);
	Validator.isValidEmail(user.email);
	if(!Validator.form.username.status) errorMessages.push(Validator.form.username.errorMessage);
	if(!Validator.form.studentNum.status) errorMessages.push(Validator.form.studentNum.errorMessage);
	if(!Validator.form.phone.status) errorMessages.push(Validator.form.phone.errorMessage);
	if(!Validator.form.email.status) errorMessages.push(Validator.form.email.errorMessage);
	if(!!users[user.username]) errorMessages.push("错误: 用户名 " + "\"" + user.username + "\" 已经被使用了！" );
	for(var name in users){
		if(users[name].studentNum == user.studentNum){
			errorMessages.push("错误: 学号 " + "\"" + user.studentNum + "\" 已经被使用了！" );
			break;
		}
	}
	for(var name in users){
		if(users[name].phone == user.phone){
			errorMessages.push("错误: 电话 " + "\"" + user.phone + "\" 已经被使用了！" );
			break;
		}
	}
	for(var name in users){
		if(users[name].email == user.email){
			errorMessages.push("错误: 邮箱 " + "\"" + user.email + "\" 已经被使用了！" );
			break;
		}
	}
}


function parseUser(userstring){
	var parms = userstring.match(/username=(.+)&studentNum=(.+)&phone=(.+)&email=(.+)/);
	var user = {
		username: parms[1],
		studentNum: parms[2],
		phone: parms[3],
		email: decodeURIComponent(parms[4]),
	};
	// console.log("user:" , user);
	return user;
}


function sendHtml(request,response){
	var username = parseUsername(request);
	if(!username || !isRegisted(username)){
		showSignupMessage(response);
	}
	else{
		showUserDetail(response, users[username]);
	}
}

function showUserDetail(response, user){
	response.writeHead(200,{"Content-Type": "text/html;charset=utf-8"});
	response.write(jade.renderFile("./jade/userDetail.jade",user));
	response.end();

}
function parseUsername(request){
	return querystring.parse(url.parse(request.url).query).username;
}


function isRegisted(username){
	return !!users[username];//强制转换
}


function showSignupMessage(response){
	var user = {
		username: "",
		studentNum: "",
		phone: "",
		email: "",
	};
	// var error = {}
	response.writeHead(200,{"Content-Type": "text/html;charset=utf-8"});
	response.write(jade.renderFile("./jade/signup.jade",{user: user,error: null}));
    response.end();
}