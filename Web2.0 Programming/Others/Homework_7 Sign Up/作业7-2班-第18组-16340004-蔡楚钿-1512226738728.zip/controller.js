var fs = require("fs");
var http = require("http");

function register(req, res){
  console.log("About to route a request for register");
  fs.readFile('index.html', function (err, data) {
    if (err) {
      return console.error(err);
    } else {
      res.writeHead(200,{'Content-type':"text/html"});
      res.write(data);
    }
  });
  fs.readFile('style.css', function (err, data) {
    if (err) {
      return console.error(err);
    } else {
      res.writeHead(200,{'Content-type':"text/css"});
      res.write(data);
    }
  });
  fs.readFile('iCheck.js', function (err, data) {
    if (err) {
      return console.error(err);
    } else {
      res.writeHead(200,{'Content-type':"text/javascript"});
      res.write(data);
    }
  });
}

function information(req, res){
  console.log("About to route a request for information");
  
  
  fs.readFile('./index.html', function (err, data) {
    if (err) {
      return console.error(err);
    } else {
      res.writeHead(200,{'Content-type':"text/html"});
      res.write(data);
    }
  });
  fs.readFile('./style.css', function (err, data) {
    if (err) {
      return console.error(err);
    } else {
      res.writeHead(200,{'Content-type':"text/css"});
      res.write(data);
    }
  });
  fs.readFile('./iCheck.js', function (err, data) {
    if (err) {
      return console.error(err);
    } else {
      res.writeHead(200,{'Content-type':"text/javascript"});
      res.write(data);
    }
  });
}

exports.register = register;