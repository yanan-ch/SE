var url = require("url");
function route(req, res, handle) {
  var pathname = url.parse(req.url).pathname;
  var search = url.parse(req.url).search;
  console.log("About to route a request for " + pathname);
  console.log("About to route a request for " + search);
  if (pathname == '/') {
    if (search == null) {
      handle['register'](req);
    } else {
      handle['information'](req);
    }
  } else {
    handle['404'];
  }
}

exports.route = route;