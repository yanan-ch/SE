var server = require("./server");
var router = require("./router");
var controller = require("./controller");

var handle = {};
handle['register'] = controller.register;
handle['information'] = controller.information;
handle['404'] = controller.error;
server.start(router.route, handle);