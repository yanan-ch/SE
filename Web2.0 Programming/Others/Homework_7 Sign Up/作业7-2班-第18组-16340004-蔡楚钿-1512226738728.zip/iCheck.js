window.onload = function() {
  document.getElementById('name').addEventListener("keyup",checkName);
  document.getElementById('id').addEventListener("keyup",checkID);
  document.getElementById('phone').addEventListener("keyup",checkPhone);
  document.getElementById('mail').addEventListener("keyup",checkEmail);
}

function checkName() {
  var name = document.getElementById('name').value;
  var Reg = /^([a-zA-Z][A-Za-z_0-9_\_]{5,17})?$/;
  if ( name.search(Reg) == -1 ) {
    document.getElementById('error_name').innerText = "用户名6~18位英文字母、数字或下划线，必须以英文字母开头";
  } else {
    document.getElementById('error_name').innerText = "";
  }
}

function checkID() {
  var id = document.getElementById('id').value;
  var Reg = /^([1-9][0-9]{7})?$/;
  if ( id.search(Reg) == -1 ) {
    document.getElementById('error_id').innerText = "学号8位数字，不能以0开头";
  } else {
    document.getElementById('error_id').innerText = "";
  }
}

function checkPhone() {
  var phone = document.getElementById('phone').value;
  var Reg = /^([1-9][0-9]{10})?$/;
  if ( phone.search(Reg) == -1 ) {
    document.getElementById('error_phone').innerText = "电话11位数字，不能以0开头";
  } else {
    document.getElementById('error_phone').innerText = "";
  }
}

function checkEmail() {
  var mail = document.getElementById('mail').value;
  var Reg = /^([\w!#$%&'*+/=?^_`{|}~-]+(?:\.[\w!#$%&'*+/=?^_`{|}~-]+)*@(?:[\w](?:[\w-]*[\w])?\.)+[\w](?:[\w-]*[\w])?)?$/;
  if ( mail.search(Reg) == -1 ) {
    document.getElementById('error_mail').innerText = "邮箱格式错误";
  } else {
    document.getElementById('error_mail').innerText = "";
  }
}