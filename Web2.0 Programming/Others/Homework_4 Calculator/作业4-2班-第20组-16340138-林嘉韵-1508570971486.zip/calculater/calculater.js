var flag = false;
function inputNum(num)
{
  if(flag)
  {
    document.getElementById("input").innerHTML = "";
    flag = false;
  }
  var len = document.getElementById("input").innerHTML.length;
  if(len == 17)
  {
    alert("算术表达式过长！");
    return;
  }
  document.getElementById("input").innerHTML  += num;
}
function inputSymbol(symbol)
{
  if(flag)
  {
    flag = false;
  }
  var len=document.getElementById("input").innerHTML.length;
  var str=document.getElementById("input").innerHTML;
  if(len==0||str[len-1]=='/'||str[len-1]=='*'||str[len-1]=='+'||str[len-1]=='-'||str[len-1]=='.')
  {
    return;
  }
  if(len == 17)
  {
    alert("算术表达式过长！");
    return;
  }
  document.getElementById("input").innerHTML  += symbol;
}
function inputDot()
{
  var len=document.getElementById("input").innerHTML.length;
  if(len==0)
  {
    return;
  }
  if(len == 17)
  {
    alert("算术表达式过长！");
    return;
  }
  document.getElementById("input").innerHTML  += ".";
}
function Delete()
{
  var len = document.getElementById("input").innerHTML.length;
  var str = document.getElementById("input").innerHTML;
  document.getElementById("input").innerHTML = str.substr(0,len-1);
}
function CE()
{
  document.getElementById("input").innerHTML  = "";
}
function Calculate()
{
  var i;
  var str=document.getElementById("input").innerHTML;
  for(i = 0;i < document.getElementById("input").innerHTML.length;i++)
  {
    if(str[i] == 0 && str[i+1] == '(')
    {
      break;
    }
    if(i==0)
    {
      if(str[i] == 0 && str[i+1] != '.')
      {
        str = str.substring(i+1);
      }
    }
    else {
      if(str[i] == 0 && ((str[i-1] == '+') || (str[i-1] == '-') || (str[i-1] == '*') || (str[i-1] == '/')) && str[i+1] != '.')
      {
        str = str.substring(0,i) + str.substring(i+1);
      }
    }

  }
  if(str == "")
    return;
  try {
    document.getElementById("input").innerHTML = eval(str);
  } catch (e) {
    alert("算术表达式非法！");
  }
  flag = true;
  document.getElementById("input").innerHTML = parseFloat(parseFloat(document.getElementById("input").innerHTML).toFixed(10)).toString();
  var len = document.getElementById("input").innerHTML.length;
  if(len > 17)
  {
    alert("算术表达式过长！");
    document.getElementById("input").innerHTML = "";
    return;
  }
  if(document.getElementById("input").innerHTML == "Infinity")
  {
    alert("算术表达式非法！");
    document.getElementById("input").innerHTML = "";
    flag=false;
  }
}
