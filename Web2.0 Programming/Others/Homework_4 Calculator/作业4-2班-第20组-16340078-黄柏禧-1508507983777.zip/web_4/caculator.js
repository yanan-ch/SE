  var check = true;
  function show(name) {
    if (check == true) {
      _clear();
    }
    var p = document.getElementById("expression");
    var s = p.innerHTML;
    s += name;
    p.innerHTML = s;
    check = false;
  }

  function _delete() {
    var p = document.getElementById("expression");
    var s = p.innerHTML;
    s = s.slice(0, -1);
    p.innerHTML = s;
  }

  function _clear() {
    var p = document.getElementById("expression");
    var s = "";
    p.innerHTML = s;
  }

  function _result() {
    var p = document.getElementById("expression");
    try {
      var r = eval(p.innerHTML);
      p.innerHTML = r;
    } catch (e) {
      alert("invalid input");
    }
    finally {
      check = true;
    }
  }
  
