var pressed_btn = document.getElementById("calculator-button");
var content = "0";
var flag = false, isOneDec = false;

pressed_btn.onclick = function clickButton(e) {
  var target = e.target;
  if(target.nodeName !== 'BUTTON') return;
  var btnType = target.textContent;

  if(flag && btnType == '←') return;
  else if(flag && btnType != '/' && btnType != '+' && btnType != '-' && btnType != '*' && btnType != '=') {
    content = "0";
    isOneDec = false;
  }

  flag = false;

  if(btnType == 'CE') {
    content = "0";
    isOneDec = false;
  }
  else if(btnType == '←') {
    if(content.length > 1) {
      if(content.charAt(content.length - 1) == '+' || content.charAt(content.length - 1) == '-' 
        || content.charAt(content.length - 1) == '*' || content.charAt(content.length - 1) == '/') {
        isOneDec = true;
      } else if(content.charAt(content.length - 1) == '.') {
        isOneDec = false;
      }
      content = content.slice(0, -1);
    }
    else if(content.length == 1) {
      content = "0";
      isOneDec = false;
    }
  }
  else if(btnType == '.') {
    if(!isOneDec) {
      if(content.charAt(content.length - 1) == '+' || content.charAt(content.length - 1) == '-' 
        || content.charAt(content.length - 1) == '*' || content.charAt(content.length - 1) == '/'
        || content.charAt(content.length - 1) == ')') {
        content += "0";
      }
      content += btnType;
      isOneDec = true;
    }
    else return;
  }
  else if(btnType == '=') {
    calculate();
  }
  else if(btnType == '+' || btnType == '-' || btnType == '*' || btnType == '/') {
    if(content.charAt(content.length - 1) == '+' 
      || content.charAt(content.length - 1) == '-' 
      || content.charAt(content.length - 1) == '*' 
      || content.charAt(content.length - 1) == '/') {
      content = content.slice(0, -1);
    }
    content += btnType;
    isOneDec = false;
  }
  else if(content === "0") content = btnType;
  else content += btnType;
  document.getElementById("screen").value = content;
}

function calculate() {
  var count = 0;
  for(var i = 0; i < content.length; i++) {
    if(content.charAt(i) === '(') {
      if(i != 0 && content.charAt(i - 1) != '+' && content.charAt(i - 1) != '-' 
        && content.charAt(i - 1) != '*' && content.charAt(i - 1) != '/'
        && content.charAt(i - 1) != '(') {
        count = -1;
        break;
      }
      else count++;
    }
    else if(content.charAt(i) === ')' && count > 0) {
      if(i != content.length - 1 && content.charAt(i + 1) != '+' && content.charAt(i + 1) != '-' 
        && content.charAt(i + 1) != '*' && content.charAt(i + 1) != '/'
        && content.charAt(i + 1) != ')') {
        count = -1;
        break;
      }
      else count--;
    }
    else if(content.charAt(i) === ')' && count == 0) count = -1;
  }

  if(count != 0) {
    alert("\"" + content + "\" 不是合法算术表达式");
    content = "0";
    isOneDec = false;
  }
  else if(eval(content) == "-Infinity" || eval(content) == "Infinity") {
    alert("除数不能为零");
    content = "0";
    isOneDec = false;
  }
  else {
    content = eval(content) + "";
    flag = true;
  }
}


