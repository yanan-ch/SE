function ondisplay(num) {
	var cur_string = document.getElementById("screen").innerHTML;
	//check dot valid
	if(num == ".") {
		if(cur_string[cur_string.length - 1] < '0' || cur_string[cur_string.length - 1] > '9')
			return;
		var dot_flag = true;
		for(var i = cur_string.length - 1; i >= 0; --i) {
			if(cur_string[i] == "." && dot_flag) {
				return;
			}
			else if(cur_string[i] < '0' || cur_string[i] > '9') {
				break;
			}
		}
	}
	if(num == ")") {
		if(cur_string[cur_string.length - 1] == '+' || cur_string[cur_string.length - 1] == '-' 
		|| cur_string[cur_string.length - 1] == '*' || cur_string[cur_string.length - 1] == '/' || cur_string[cur_string.length - 1] == '.'
		|| cur_string[cur_string.length - 1] == '(')
			return;
	}
	if(num == "(") {
		if(cur_string[cur_string.length - 1] == '.')
			return;
		if(cur_string[cur_string.length - 1] >= '0' && cur_string[cur_string.length - 1] <= '9') 
			return;
	}
	if(cur_string.length > 22)
		return;
	document.getElementById("screen").innerHTML += num;
}
function plus() {
	var cur_string = document.getElementById("screen").innerHTML;
	if(cur_string[cur_string.length - 1] == '+' || cur_string[cur_string.length - 1] == '-' 
		|| cur_string[cur_string.length - 1] == '*' || cur_string[cur_string.length - 1] == '/' || cur_string[cur_string.length - 1] == '.')
			return;
	if(cur_string.length > 15)
		return;
	document.getElementById("screen").innerHTML += "+";
}
function minus() {
	var cur_string = document.getElementById("screen").innerHTML;
	if(cur_string[cur_string.length - 1] == '+' || cur_string[cur_string.length - 1] == '-' 
		|| cur_string[cur_string.length - 1] == '*' || cur_string[cur_string.length - 1] == '/' || cur_string[cur_string.length - 1] == '.')
			return;
	if(cur_string.length > 15)
		return;
	document.getElementById("screen").innerHTML += "-";
}
function multiply() {
	var cur_string = document.getElementById("screen").innerHTML;
	if(cur_string[cur_string.length - 1] == '+' || cur_string[cur_string.length - 1] == '-' 
		|| cur_string[cur_string.length - 1] == '*' || cur_string[cur_string.length - 1] == '/' || cur_string[cur_string.length - 1] == '.')
			return;
	if(cur_string.length > 15)
		return;
	document.getElementById("screen").innerHTML += "*";
}
function divide() {
	var cur_string = document.getElementById("screen").innerHTML;
	if(cur_string[cur_string.length - 1] == '+' || cur_string[cur_string.length - 1] == '-' 
		|| cur_string[cur_string.length - 1] == '*' || cur_string[cur_string.length - 1] == '/' || cur_string[cur_string.length - 1] == '.')
			return;
	if(cur_string.length > 15)
		return;
	document.getElementById("screen").innerHTML += "/";
}
function equal() {
	var string = document.getElementById("screen").innerHTML;
	if(string.length == 0)
		return;
	try{
		var result = eval(string);
		if(result == NaN || result == Infinity) {
			alert("plz don't divide 0");
			document.getElementById("screen").innerHTML = "";
		}
		else {
			result *= 100000000;
			result = Math.round(result);
			result /= 100000000;
			document.getElementById("screen").innerHTML = result;
		}
	}
	catch(SyntaxError) {
		alert("error input!");
		document.getElementById("screen").innerHTML = "";
	}
}
function ac() {
	document.getElementById("screen").innerHTML = "";
}
function ce() {
	var tmp = document.getElementById("screen").innerHTML;
	tmp = tmp.substr(0, tmp.length - 1);
	if(tmp.length > 0 && tmp[0] != '-') {
		document.getElementById("screen").innerHTML = tmp;
	}
	else {
		document.getElementById("screen").innerHTML = "";
	}
}