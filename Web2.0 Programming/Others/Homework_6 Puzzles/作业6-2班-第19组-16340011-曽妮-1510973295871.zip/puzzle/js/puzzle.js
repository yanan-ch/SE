
//初始化拼图
function createCells() {
	$("#cell-container").empty();
	for (var i = 0; i < mode * mode; i++) {
		// var position = (i%mode*100/mode).toString() + "% " + (Math.floor(i/mode)*100/mode).toString() + "%";
		var position = "-" + (i%mode/mode*500).toString() + "px -" + (Math.floor(i/mode)/mode*500).toString() + "px";
		var cell = $("<div></div>");
		cell.addClass(pic);
		cell.addClass("mode"+mode);
		cell.addClass("mode"+mode+"-"+i);
		cell.css({
			"background-position": position
		});
		cell.attr("order", i);
		$("#cell-container").append(cell);
		// console.log(position);
	}
	$(".mode"+mode).eq(mode*mode-1).attr("id", "empty");
}

function modifyCells() {
	//交换位置和序号
	for (var i = 0; i < mode*mode - 1; i++) {
		var ran = Math.round(Math.random() * 100 ) % (mode*mode - 1);
		var order_temp = $(".mode"+mode).eq(i).attr("order");
		$(".mode"+mode).eq(i).removeClass(function() { return "mode"+mode+"-"+$(this).attr("order"); });
		$(".mode"+mode).eq(i).attr("order", $(".mode"+mode).eq(ran).attr("order"));
		$(".mode"+mode).eq(i).addClass(function() { return "mode"+mode+"-"+$(this).attr("order"); });
		$(".mode"+mode).eq(ran).removeClass(function() { return "mode"+mode+"-"+$(this).attr("order"); });
		$(".mode"+mode).eq(ran).attr("order", order_temp);
		$(".mode"+mode).eq(ran).addClass(function() { return "mode"+mode+"-"+$(this).attr("order"); });
	}

	var antiCount = 0; //逆序数

	for (var i = 0; i < mode*mode - 1; i++)
		for (var j = i + 1; j <= mode*mode - 1; j++)
			if ($(".mode"+mode).eq(i).attr("order") > $(".mode"+mode).eq(j).attr("order"))
				antiCount++;

	if (antiCount % 2 != 0) modifyCells(); //逆序数不为偶时重新打乱
}

function check() {
	for (var i = 0; i < mode*mode - 1; i++)
		if ($(".mode"+mode).eq(i).attr("order") != i)
			return false;
	return true;
}

function win() {
	$("h1").html("You Win!");
	starFlag = false;
	createCells();
}

function move(that) {
	console.log("moving");
	var order_temp = $(that).attr("order");
	$(that).removeClass(function() { return "mode"+mode+"-"+$(this).attr("order"); });
	$(that).attr("order", $("#empty").attr("order"));
	$(that).addClass(function() { return "mode"+mode+"-"+$(this).attr("order"); });
	$("#empty").removeClass(function() { return "mode"+mode+"-"+$(this).attr("order"); });
	$("#empty").attr("order", order_temp);
	$("#empty").addClass(function() { return "mode"+mode+"-"+$(this).attr("order"); });

	if (check()) win();
}

$(document).ready(function(){
	$(document).bind("selectstart",function(){return false;});


	$("#Normal").addClass("current");
	starFlag = false;
	mode = 4;
	pic = "Panda";
	createCells();


	//hint button
	$("#Hint").mouseover(function() {
		$(this).toggleClass("current");
		$("#pictrue img").fadeToggle();
	});
	$("#Hint").mouseout(function() {
		$(this).toggleClass("current");
		$("#pictrue img").fadeToggle();
	});


	//start or retart game
	$("#Start").click(function() {
		startFlag = true;
		$("h1").html("The Puzzle");
		$(this).html("Restart");
		modifyCells();
	})

	//change levels
	$(".level").click(function() {
		$(".level").removeClass("current");
		$(this).addClass("current");
		var oldmode = mode;
		switch($(this).attr("id")) {
			case "Easy": mode = 3; break;
			case "Normal": mode = 4; break;
			case "Hard": mode = 5; break;
			case "Hell": mode = 6; break;
			default:
				mode = 4;
				$(".level").removeClass("current");
				$("#Normal").addClass("current");
				break;
		}
		if (oldmode != mode) {
			createCells();
			startFlag = false;
			$("#Start").html("Start");
		}
	})

	$("#cell-container").delegate("div", "click", function() {
		if (!startFlag) return;
		var dis_top = Math.abs($(this).position().top - $("#empty").position().top);
		var dis_left = Math.abs($(this).position().left - $("#empty").position().left);
		console.log(dis_top + " " + dis_left);
		if ((dis_top + dis_left) - 500/mode < 10) {
			var that = this;
			move(that);
		}
		// console.log($(this).position().top + " " + $(this).position().left);
	})

	$("select").change(function() {
		var oldpic = pic;
		pic = $(this).find('option:selected').html();
		if (oldpic != pic) {
			$("#pictrue img").attr("src", "img/"+pic+".jpg");
			createCells();
			startFlag = false;
			$("#Start").html("Start");
		}
	})

});