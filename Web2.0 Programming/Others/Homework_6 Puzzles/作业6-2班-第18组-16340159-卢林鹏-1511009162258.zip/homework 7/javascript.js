


$(document).ready(function() {
	




	start_end = false;
	$("#start").click(function(){
		$("#start").addClass("clicked");
		$("#start").removeClass("button");
		while(start_end){
			for(var i = 1; i <= 16; i++){
	        		class_name = "picture_" ;
	        		class_name += i;
	        		$("#board").children("div:nth-child("+ i +")").attr("class",class_name);
	        	}
	        	start_end = false;
		}
		
        var num = new Array();
        num[0] = -1;
        num[16] = 0;
        var sign = 0;
        while(1){
	        for(var i = 1; i < 16; i++ ) random_num(num,i);
            for(var i = 2; i <= 16; i++ ){
	           for(var k = 1; k < i; k++)
	           	  if(num[k] > num[i]) 
	           	  	sign == 0 ? sign = 1: sign = 0;
	         }
	        if(sign == 1){
	        	for(var i = 1; i < 16; i++){
	        		class_name = "picture_" ;
	        		class_name += num[i];
	        		$("#board").children("div:nth-child("+ i +")").attr("class",class_name);
	        	}
	        	break;
	        }
    	}
    	start_end = true;
    	$("#board").children("div").unbind("click");
		$("#board").children("div").click(function(){
			Move(this);
		});
	});
    




    var on = false;
	$("#hint").click(function(){
         if(on == false) {
         	$("img").removeClass("hide");
         	$("#hint").addClass("clicked");
         	$("#hint").removeClass("button");
         }
         else{
         	$("img").addClass("hide");
         	$("#hint").removeClass("clicked");
         	$("#hint").addClass("button");
         }
         on = ~on;
	});



	


	$("#reset").click(function(){
         for(var i = 1; i <= 16; i++){
	        		class_name = "picture_" ;
	        		class_name += i;
	        		$("#board").children("div:nth-child("+ i +")").attr("class",class_name);
	        	}
        $("#start").addClass("button");
		$("#start").removeClass("clicked");
		$("#board").children("div").unbind("click");
		alert("请点击重新开始再次进行游戏！！");
	});


    

    function random_num(num,i){
    	var x = Math.floor(Math.random() * 16);
    	var sign1 = true;
    	while(1){
    		for(var k = 0; k < i;k++){
    			if(num[k] == x || x == 0) {
    				x = Math.floor(Math.random() * 16);
    				sign1 = true;
    				break;
    			}
    			else
    				sign1 = false;
    		}
    		if(!sign1){
    			num[i] = x;
    			break;
    		}
    	}
     };

	




	function Move(clicked_square) {
		var movable = false;
		var white_x = $("#board").children("div:nth-child(16)").css("left");
		var white_y = $("#board").children("div:nth-child(16)").css("top");

		var picture_x = $(clicked_square).css("left");
		var picture_y = $(clicked_square).css("top");
		if(white_x == picture_x && picture_y == (parseFloat(white_y) + 97.5) + "px")
             movable = true;
        if(white_x == picture_x && picture_y == (parseFloat(white_y) - 97.5) + "px")
             movable = true;
        if(white_y == picture_y && picture_x == (parseFloat(white_x) + 97.5) + "px")
             movable = true;
        if(white_y == picture_y && picture_x == (parseFloat(white_x) - 97.5) + "px")
             movable = true;     


        if(movable){
        	var class_name = $(clicked_square).attr("class");
        	var class_name1= $("#board").children("div:nth-child(16)").attr("class");
            $(clicked_square).attr("class",class_name1);
            $("#board").children("div:nth-child(16)").attr("class",class_name);
            Win();
        }  
	};
	


	function Win(){
		var sign = true;
		for(var i = 1; i <= 16; i++){
			class_name = "picture_";
			class_name += i;
            if($("#board").children("div:nth-child("+ i +")").attr("class") != class_name){
            	sign = false;
            	break;
            }
		}
		if(sign) {
			$("#board").children("div").unbind("click");
			alert("You Win");
		}
	}
})