function output = main(image)
    img = imread(image);
    % imhist(img);
    [x, y] = size(img);
    output = zeros(x, y);
    T = 130;
    delta_T = 1;
    % g1
    sum1 = 0;
    sum2 = 0;
    count1 = 0;
    count2 = 0;
    for i = 1:x
        for j = 1:y
            if img(i, j) > T
                sum1 = sum1 + img(i, j);
                count1 = count1 + 1;
            else
                sum2 = sum2 + img(i, j);
                count2 = count2 + 1;
            end
        end
    end
    m1 = sum1 / count1;
    m2 = sum2 / count2;
    T_update = (m1 + m2) / 2;
    while abs(T_update - T) > delta_T
        sum1 = 0;
        sum2 = 0;
        count1 = 0;
        count2 = 0;
        for i = 1:x
            for j = 1:y
                if img(i, j) > T
                    sum1 = sum1 + img(i, j);
                    count1 = count1 + 1;
                else
                    sum2 = sum2 + img(i, j);
                    count2 = count2 + 1;
                end
            end
        end
        m1 = sum1 / count1;
        m2 = sum2 / count2;
        T = T_update;
        T_update = (m1 + m2) / 2;
    end
    for i = 1:x
        for j = 1:y
            if img(i, j) > T
                output(i, j) = 255;
            else
                output(i, j) = 0;
            end
        end
    end
    figure;
    subplot(1,2,1), imshow(img), title('Origin');
    subplot(1,2,2), imshow(output), title('Processed');
end