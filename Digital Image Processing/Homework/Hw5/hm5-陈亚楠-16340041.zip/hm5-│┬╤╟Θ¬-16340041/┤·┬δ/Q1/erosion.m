function output = erosion(matrix, structure, centerX, centerY)
    [x, y] = size(matrix);
    [m, n] = size(structure);
    output = zeros(x, y);
    num = sum(sum(structure == 1));
    for i = (1+centerX-1):(x-(m-centerX))
        for j = (1+centerY-1):(y-(n-centerY))
            tag = false;
            count = 0;
            for u = 1:m
                for v = 1:n
                    if structure(u, v) == 0
                        continue;
                    end
                    if structure(u, v) == 1
                        if matrix(i+(u-(m-v))-(centerX-(m-v)), j+(v-(n-v))-(centerY-(n-v))) == 1
                            count = count + 1;
                        end
                    end
                    if count == num
                        tag = true;
                        break;
                    end
                end
            end
            if tag == true
                output(i, j) = 1;
            end
        end
    end
end