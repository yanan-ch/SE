function output = close(matrix, structure, centerX, centerY)
    dilationTmp = dilation(matrix, structure, centerX, centerY);
    output = erosion(dilationTmp, structure, centerX, centerY);
end