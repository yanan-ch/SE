function output = open(matrix, structure, centerX, centerY)
    erosionTmp = erosion(matrix, structure, centerX, centerY);
    output = dilation(erosionTmp, structure, centerX, centerY);
end