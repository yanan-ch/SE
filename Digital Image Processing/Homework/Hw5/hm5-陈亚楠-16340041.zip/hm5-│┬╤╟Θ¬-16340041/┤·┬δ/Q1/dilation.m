function output = dilation(matrix, structure, centerX, centerY)
    [x, y] = size(matrix);
    [m, n] = size(structure);
    output = zeros(x, y);
    for i = (1+centerX-1):(x-(m-centerX))
        for j = (1+centerY-1):(y-(n-centerY))
            tag = false;
            for u = 1:m
                for v = 1:n
                    if structure(u, v) == 0
                        continue;
                    end
                    if structure(u, v) == 1
                        if matrix(i+(u-(m-1))-(centerX-(m-1)), j+(v-(n-1))-(centerY-(n-1))) == 1
                            tag = true;
                            break;
                        end
                    end
                end
            end
            if tag == true
                output(i, j) = 1;
            end
        end
    end
end