function output = main()
    matrix = [0 0 0 0 0 0 0;
              0 0 1 1 0 0 0;
              0 0 0 1 0 0 0;
              0 0 0 1 1 0 0;
              0 0 1 1 1 1 0;
              0 0 1 1 1 0 0;
              0 1 0 1 0 1 0;
              0 0 0 0 0 0 0];
    se1 = [1 1 1];
    se2 = [1 1;
           0 1];
    qa = dilation(matrix, se1, 1, 1)
    qb = erosion(matrix, se1, 1, 1)
    qc = dilation(matrix, se2, 1, 2)
    qd = erosion(matrix, se2, 1, 2)
    qe1 = open(matrix, se1, 1, 1)
    qe2 = open(matrix, se2, 1, 2)
    qf1 = close(matrix, se1, 1, 1)
    qf2 = close(matrix, se2, 1, 2)
end