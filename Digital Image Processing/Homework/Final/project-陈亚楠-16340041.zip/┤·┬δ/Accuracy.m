function Accuracy()
    x = 50:1:100;
    y = [];
    for i = 50:1:100
        temp = [];
        for j = 1:1:100
            accuracy = Eigenfaces(i);
            temp = [temp, accuracy];
        end
        avg = mean(temp);
        y = [y, avg];
    end
    plot(x,y);
    title('Accuracy Rate');
    xlabel('k');
    ylabel('percentage');
    axis([50 100 0.50 1.00]); 
end