# Digital Image Processing Hw2

| 学号     | 姓名   |
| ------ | ------ |
| 16340041 | 陈亚楠 |

## Q1:

### Description

给定图像`car.png`和模版图像`wheel.png`，利用相关检测实现对`car`图像中的`wheel`检测,具有最大相关值的位置可以解释为所检测到的`wheel`位置。程序的输入是图像和模版，要求：

1. 显示图像的相关值结果；
2. 列出在图像中检测到的所有目标的`(x, y)`坐标。

### Answer

#### 总体思路：

**将图像与模板进行相关运算，相关函数的值最大的位置即检测到的目标位置**；

在本题中，如果模版图像`wheel.png`匹配到图像`car.png`中一个像素灰度值都较大的区域，也可能会有较大的相应输出，从而得到错误的结果。因此我们需要对相关匹配公式进行改造，这里我们使用相关函数为：
$$
G(i,j)= \frac 
{\sum_{u=-k}^{k} \sum_{v=-l}^{l}H(u,v)F(i+u,j+v)} 
{\sum_{u=-k}^{k} \sum_{v=-l}^{l}F^2(i+u,j+v)}
$$
其中，$H(u,v)$为匹配模板，分母为图像内容。

#### 实现步骤：

1. 读取指定图像`car.png`与模板图像`wheel.png`并将图像保存到矩阵`origin`,，`template`中；

   > 由于在`Matlab`中，`imread()`函数读取图像得到的数据采用`unit8`类型，因此这里需要进行归一化将图像矩阵数据类型转换成浮点数形式；

   ```matlab
   %read images
   origin = imread(origin);
   template = imread(template);
   %unit8 to double
   origin = im2double(origin);
   template = im2double(template);
   ```

2. 分别获取两个图像矩阵的行数与列数；

   ```matlab
   %get size
   [row1, col1] = size(origin);
   [row2, col2] = size(template);
   ```

3. 对图像矩阵进行零填充；

   ```matlab
   %zero padding
   zeroPaddingImg = zeros(row1+2*(row2-1), col1+2*(col2-1));
   %half height, width of template
   halfRow = floor(row2 / 2);
   halfCol = floor(col2 / 2);
   zeroPaddingImg(row2 : row2+row1-1, col2 : col2+col1-1) = origin;
   ```

4. 根据相关匹配公式对指定图像`car.png`与模板图像`wheel.png`进行相关运算并得到相关值矩阵`correlationImg`；

   ```matlab
   correlationImg = zeros(row1+2*(row2-1), col1+2*(col2-1));
   %correlation operation
   for i = halfRow : (halfRow+row1)
       for j = halfCol : (halfCol+col1)
           sum1 = 0;
           sum2 = 0;
           for u = 1 : row2
               for v = 1 : col2
                   sum1 = sum1 + zeroPaddingImg(i+u, j+v) * template(u, v);
                   sum2 = sum2 + zeroPaddingImg(i+u, j+v) ^ 2;
               end
           end
           correlationImg(i, j) = sum1 / sum2;
       end
   end
   ```

5. 对相关值矩阵进行裁剪得到`clipCorrelationImg`；

   ```matlab
   %clip padding
   clipCorrelationImg = zeros(row1, col1);
   clipCorrelationImg = correlationImg(row2:row2+row1-1, col2:col2+col1-1);
   clipCorrelationImg = im2uint8(mat2gray(clipCorrelationImg));
   ```

6. 输出显示相关值矩阵表示的图像；

#### 实现结果：

![Q1_result1](Q1_result1.png)

在图像中检测到的所有目标的`(x, y)`坐标已在图中标出。



## Q2:

### Description

产生椒盐噪声图像，实现采用中值滤波：

1. 分别产生2个独立、在区间$[0,255]$内均匀分布的随机矩阵$t_1(x,y)$和$t_2(x,y)$，这里$t_1(x,y) \neq t_2(x,y)$。

2. 设输入图像`sport car.pgm`为 $f_0(x,y)$，采用下式产生椒盐噪声图像：
$$
f(x,y) = 
\begin{cases}
255,  & \text{if $f_0(x,y)>t_1(x,y)$} \\[2ex]
0,  & \text{if $f_0(x,y)<t_2(x,y)$} \\[2ex]
\text{$f_0(x,y)$} & \text{otherwise}
\end{cases}
$$

3. 采用$3*3$窗口实现中值滤波，注：不能使用`Matlab`中的`medfilt2`。

4. 显示原图像、 椒盐噪声图像、 中值滤波图像， 并和采用`Matlab ‘medfilt2’`的结果做比较。 

### Answer

#### 实现步骤：

1. 读取输入图像，产生两个随机矩阵：

   - 使用`Matlab`的`imread()`函数扫描给定图像`sport car.pgm`得到图像矩阵`origin`，并使用`Matlab`的`size()`函数获取图像矩阵的行数`row`和列数`col`；

   - 使用`randi()`函数生成2个独立的、在区间$[0,255]$内均匀分布的、大小为$row*col$的随机矩阵`t1`和`t2`；

     ```matlab
     origin = imread(originImg);
     [row, col] = size(origin);
     t1 = randi([0 255], row, col);
     t2 = randi([0 255], row, col);
     ```

2. 采用题目要求方式产生椒盐噪声图像`noiseImg`：

   ```matlab
   noiseImg = origin;
   for i = 1 : row
       for j = 1 : col
           if origin(i, j) > t1(i, j)
           	noiseImg(i, j) = 255;
           end
           if origin(i, j) < t2(i, j)
           	noiseImg(i, j) = 0;
       	end
       end
   end
   ```

3. 采用$3*3$窗口实现中值滤波：

   - 构造$3*3$矩阵`medianFilter`，循环遍历噪声图像`noiseImg`；

   - 对于图像中的每个像素，将其邻域内的像素值存入矩阵`medianFilter`中，不在图像中的像素点记为0；

   - 将`medianFilter`向量化并调用`median()`求出中值；

   - 将当前像素值替换成求出来的中值；

     ```matlab
     medianImg = zeros(row, col);
     for i = 1 : row
         for j = 1 : col
             medianFilter = zeros(3, 3);
             for m = -1 : 1
                 for n = -1 : 1
                     if (i+m>=1) && (j+n>=1) && (i+m<=row) && (j+n<=col)
                         medianFilter(m + 2, n + 2) = noiseImg(i + m, j + n);
                     end
                 end
             end
             %vector
             medianFilter = medianFilter(:);
             medianImg(i, j) = median(medianFilter);
         end
     end
     ```

4. 显示结果图像，并将得到的图像进行对比；

#### 实现结果：

![Q2_result](Q2_result.png)

