function medianFilterInPepperSaltNoise = myFun(originImg)
    %read image
    origin = imread(originImg);
    %get size
    [row, col] = size(origin);
    %randomly generate matrix
    t1 = randi([0 255], row, col);
    t2 = randi([0 255], row, col);
    %generate pepper-salt noise image
    noiseImg = origin;
    for i = 1 : row
        for j = 1 : col
            if origin(i, j) > t1(i, j)
                noiseImg(i, j) = 255;
            end
            if origin(i, j) < t2(i, j)
                noiseImg(i, j) = 0;
            end
        end
    end
    %median filter
    medianImg = zeros(row, col);
    for i = 1 : row
        for j = 1 : col
            medianFilter = zeros(3, 3);
            for m = -1 : 1
                for n = -1 : 1
                    if (i + m >= 1) && (j + n >= 1) && (i + m <= row) && (j + n <= col)
                        medianFilter(m + 2, n + 2) = noiseImg(i + m, j + n);
                    end
                end
            end
            %vector
            medianFilter = medianFilter(:);
            medianImg(i, j) = median(medianFilter);
        end
    end
    %display
    figure
    subplot(2, 2, 1), imshow(origin), title('Origin Image');
    subplot(2, 2, 2), imshow(noiseImg), title('Pepper-salt Noise Image');
    subplot(2, 2, 3), imshow(medianImg), title('Median Filter Image');
    subplot(2, 2, 4), imshow(medfilt2(noiseImg, [3, 3])), title(' Use medfilt2()');
end