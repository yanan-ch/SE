clear;
medianFilterInPepperSaltNoise('sport car.pgm');