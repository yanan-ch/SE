clear;
correlation('car.png', 'wheel.png');