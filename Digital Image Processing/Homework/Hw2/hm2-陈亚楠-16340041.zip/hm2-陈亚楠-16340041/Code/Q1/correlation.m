function [correlationImg] = correlation(origin, template)
    %read images
    origin = imread(origin);
    template = imread(template);
    %get size
    [row1, col1] = size(origin);
    [row2, col2] = size(template);
    %unit8 to double
    origin = im2double(origin);
    template = im2double(template);
    %zero padding
    zeroPaddingImg = zeros(row1+2*(row2-1), col1+2*(col2-1));
    %half height, width of template
    halfRow = floor(row2 / 2);
    halfCol = floor(col2 / 2);
    zeroPaddingImg(row2 : row2+row1-1, col2 : col2+col1-1) = origin;
    %correlation image
    correlationImg = zeros(row1+2*(row2-1), col1+2*(col2-1));
    %correlation operation
    for i = halfRow : (halfRow+row1)
        for j = halfCol : (halfCol+col1)
            sum1 = 0;
            sum2 = 0;
            for u = 1 : row2
                for v = 1 : col2
                    sum1 = sum1 + zeroPaddingImg(i+u, j+v) * template(u, v);
                    sum2 = sum2 + zeroPaddingImg(i+u, j+v) ^ 2;
                end
            end
            correlationImg(i, j) = sum1 / sum2;
        end
    end
    %clip padding
    clipCorrelationImg = zeros(row1, col1);
    clipCorrelationImg = correlationImg(row2:row2+row1-1, col2:col2+col1-1);
    clipCorrelationImg = im2uint8(mat2gray(clipCorrelationImg));
    figure
    subplot(2,1,1), imshow(origin), title('Original Image')
    subplot(2,1,2), imshow(clipCorrelationImg), title('Correlation Image'), axis on,xlabel x, ylabel y;
end