function ButterworthTest()
    figure;
    subplot(2,2,1),imshow(Butterworth(10)),title('D0 = 10');
    subplot(2,2,2),imshow(Butterworth(20)),title('D0 = 20');
    subplot(2,2,3),imshow(Butterworth(40)),title('D0 = 40');
    subplot(2,2,4),imshow(Butterworth(80)),title('D0 = 80');