function resultImg = Butterworth(D0)
    origin = imread('barb.png');
    [M, N] = size(origin);
    P = 2 * M;
    Q = 2 * N;
    % 填充矩阵
    paddingImg = zeros(P, Q);
    for i = 1:M
        for j = 1:N
            paddingImg(i, j) = origin(i, j);
        end
    end
    paddingImg = im2uint8(mat2gray(paddingImg));
    % 中心变换矩阵
   middleImg = zeros(P, Q);
    for x = 1:P
        for y = 1:Q
           middleImg(x, y) = (-1) ^ (x + y) * paddingImg(x, y);
        end
    end
    middleImg = im2uint8(mat2gray(middleImg));
    % FFT2傅里叶变换
    transImg = fft2(middleImg);
    % Butterworth低通滤波
   filterImg = zeros(P, Q);
    for u = 1:P
        for v = 1:Q
            D = ((u - P / 2)^2 + (v - Q / 2)^2)^(1/2);
            H = 1 / (1 + (D / D0)^2);
           filterImg(u, v) = H * transImg(u, v);
        end
    end
    % DFT反变换取实部
    processImg = real(ifft2(filterImg));
    % 反中心变换
    for x = 1:P
        for y = 1:Q
            processImg(x, y) =  processImg(x, y) * ((-1) ^ (x + y));
        end
    end
    processImg = im2uint8(mat2gray(processImg));
    % 结果
    resultImg = processImg(1:M, 1:N);
end