function processImg = homomorphic(D0)
    origin = imread('office.jpg');
    gammaH = 2;
    gammaL = 0.25;
    C = 1;
    M = size(origin, 1);  
    N = size(origin, 2);
    P = floor(M / 2);
    Q = floor(N / 2);
    % 对数矩阵
    logImg = log(double(origin) + 1);
    % 变换矩阵
    transImg = fft2(logImg);
    % ̬ͬ同态滤波
    filterImg = zeros(M, N);
    for u = 1:M
        for v = 1:N
            D = ((u - P / 2)^2 + (v - Q / 2)^2)^(1/2);
            H =  (gammaH - gammaL) * (1 - exp(-C * ((D ^ 2)/(D0 ^ 2)))) + gammaL;
            filterImg(u, v) = H * transImg(u, v);
        end
    end
    processImg = real(exp(ifft2(filterImg)));
    % 处理滤波矩阵
    max = 0;
    min = 255;
    for i = 1:M
        for j = 1:N
            if processImg(i, j) > max
                max = processImg(i, j);
            end
            if processImg(i, j) < min
                min = processImg(i, j);
            end
        end
    end
    range = max - min;
    for i = 1:M
        for j = 1:N
            processImg(i, j) = 255 * (processImg(i, j) - min) / range;
        end
    end
    processImg = im2uint8(mat2gray(processImg));
end