function homomorphicTest()
    figure;
    subplot(4,2,1),imshow(homomorphic(10)),title('Homomorphic: D0 = 10');
    subplot(4,2,3),imshow(homomorphic(20)),title('Homomorphic: D0 = 20');
    subplot(4,2,5),imshow(homomorphic(40)),title('Homomorphic: D0 = 40');
    subplot(4,2,7),imshow(homomorphic(80)),title('Homomorphic: D0 = 80');

    subplot(4,2,2),imshow(ButterwortHighpass(10)),title('ButterwortHighpass: D0 = 10');
    subplot(4,2,4),imshow(ButterwortHighpass(20)),title('ButterwortHighpass: D0 = 20');
    subplot(4,2,6),imshow(ButterwortHighpass(40)),title('ButterwortHighpass: D0 = 40');
    subplot(4,2,8),imshow(ButterwortHighpass(80)),title('ButterwortHighpass: D0 = 80');