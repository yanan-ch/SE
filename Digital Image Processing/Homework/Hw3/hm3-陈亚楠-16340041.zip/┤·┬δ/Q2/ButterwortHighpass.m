function resultImg = ButterwortHighpass(D0)
    I = imread('office.jpg');
    M = size(I, 1);  
    N = size(I, 2);
    P = 2 * M;
    Q = 2 * N;
    paddingImg = zeros(P, Q);
    for i = 1:M
        for j = 1:N
            paddingImg(i, j) = I(i, j);
        end
    end
    paddingImg = im2uint8(mat2gray(paddingImg));
    middleImg = zeros(P, Q);
    for x = 1:P
        for y = 1:Q
            middleImg(x, y) = (-1) ^ (x + y) * paddingImg(x, y);
        end
    end
    middleImg = im2uint8(mat2gray(middleImg));
    transImg = fft2(middleImg);
    filterImg = zeros(P, Q);
    for u = 1:P
        for v = 1:Q
            D = ((u - P / 2)^2 + (v - Q / 2)^2)^(1/2);
            H = 1 / (1 + (D0 / D)^2);
            filterImg(u, v) = H * transImg(u, v);
        end
    end
    processImg = real(ifft2(filterImg));
    for x = 1:P
        for y = 1:Q
            processImg(x, y) =  processImg(x, y) * ((-1) ^ (x + y));
        end
    end
    processImg = im2uint8(mat2gray(processImg));
    resultImg = processImg(1:M, 1:N);