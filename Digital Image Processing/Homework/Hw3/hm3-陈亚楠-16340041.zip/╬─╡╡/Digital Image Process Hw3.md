# Digital Image Process Hw3

## Q1

### Description:

给定图像`barb.png`，利用一阶`Butterworth`低通滤波器进行频域滤波，当$D_ 0=10,20,40,80$时，给出相应滤波图像，并分别以频域和空域的观点解释有关滤波结果。 

### Solution:

#### Algorithm:

- 读取图像`barb.png`获得图像矩阵`origin`、图像的大小`M`和`N`；

- 构造填充矩阵`paddingImg`：

  初始化$P = 2M，Q = 2N$，
  $$
  paddingImg(p,q) =
          \begin{cases}
          origin(p,q),  & \text{$0 \leq p \leq M,0 \leq q \leq N$} \\
          0, & \text{其它}
          \end{cases}
  $$

- 以 $(-1)^{x+y}$乘以填充矩阵`paddingImg`进行中心变换，得到中心变换矩阵`middleImg`； 

- 对中心变换矩阵`middleImg`直接以`FFT2`进行傅立叶变换，得到变换矩阵`transImg`； 

- 对变换矩阵`transImg`进行`Butterworth`低通滤波，得到滤波矩阵`filterImg`，`Butterworth`低通滤波器公式为：
  $$
  H(u,v)=\frac{1}{1+[D(u,v)/D_0]^{2n}}
  $$
  其中
  $$
  D(u,v)=\sqrt{(u-\frac{P}{2})^2+(v-\frac{Q}{2})^2}
  $$

-  对滤波矩阵`filterImg`进行`DFT`反变换后取实部得到矩阵`processImg`;

- 以 $(-1)^{x+y}$乘以矩阵`processImg`，进行反中心变换后截取矩阵得到结果`resultImg`；

#### Result:

![q1](C:\Users\cheny\Desktop\hm3-陈亚楠-16340041\图像\Q1\q1.jpg)

#### Explanation：

- 频域：

  低通滤波是一种低频信号能正常通过，而超过设定临界值的高频信号则被阻隔，削弱的过滤方式。将图像进行傅里叶变换之后，得到图像在频域上的显示。

  ![q1_explain](C:\Users\cheny\Desktop\hm3-陈亚楠-16340041\图像\Q1\q1_explain.png)

  一阶`Butterworth`低通滤波器对频域上的图像信号进行处理，图像中低频信号保留，高频信号被削弱甚至阻隔。根据一阶`Butterworth`低通滤波器函数图像可以看到低频和高频过渡部分比较平滑，在一定程度上避免了理想低通滤波器的振铃现象。根据公式和处理的图像结果，随着$D_0$的不断增大，图像保留的低频范围越来越大，使得保留的信号越来越多，所以图像越来越清晰。

- 空域：

  在空域中，高频信号体现在图像的细节中。图像进行低通滤波后，图像的细节被滤去，所以图像显得模糊，只能看到大概的轮廓。根据处理后图像，随着$D_0$的不断增大，图像保留的低频范围越来越大，使得保留的信号越来越多，越来越多细节得以保留，所以图像越来越清晰。

## Q2

### Description:

采用同态滤波来增强图像`office.jpg `细节，对数频域滤波器为 :
$$
H(u.v) = (\gamma_H - \gamma_L)[1-e^{-c[D^2(u,v)/D_0^2]}]+\gamma_L
$$
(1) 参数选择：参考$\gamma_H=2,\gamma_L=0.25,C=1$；

(2) 自己尝试不同的$D_0$以得到最好的结果；

(3) 如将滤波器替换为一阶`Butterworth`高通滤波器，比较滤波结果。

### Solution:

#### Algorithm:

**同态滤波**：

- 读取图像`office.png`获得图像矩阵`origin`、图像的大小`M`和`N`；

- 令$P = M / 2，Q = N / 2$，对矩阵`origin`取对数得到对数矩阵`logImg`；

- 对对数矩阵`logImg`直接以`FFT2`进行傅立叶变换，得到变换矩阵`transImg`； 

- 对变换矩阵`transImg`进行同态滤波，得到滤波矩阵`filterImg`，同态滤波器公式为：
  $$
  H(u.v) = (\gamma_H - \gamma_L)[1-e^{-c[D^2(u,v)/D_0^2]}]+\gamma_L
  $$
  其中
  $$
  D(u,v)=\sqrt{(u-\frac{P}{2})^2+(v-\frac{Q}{2})^2}
  $$

-  对滤波矩阵`filterImg`进行`DFT`反变换后取实部并指数还原得到矩阵`processImg`；

- 按照下面的方法，对矩阵`processImg`进行处理，输出结果：

  确定图像的最大和最小像素值`max`和`min`，得到`range=max-min`，对于`f(x,y)`，以`255*(f(x,y)-min)/range`，得到最好的显示效果 ;

#### Result：

![q2](C:\Users\cheny\Desktop\hm3-陈亚楠-16340041\图像\Q2\q2.jpg)

#### Explanation：

随着$D_0$的增大，一阶`Butterworth`高通滤波器对细节的表现越来越差，对水印的处理不太好，图像中物体的轮廓较为模糊；同态滤波则表现了很好的水印过滤能力，保留了原来图像大致轮廓，但是比较原图像，细节处理不好。

同态滤波把频率过滤和灰度变换结合起来，以图像的照度/反射率模型作为频域处理的基础，通过调整图像灰度范围和增强对比度来改善图像的质量，使图像处理符合人眼对于亮度响应的非线性特性，避免了直接对图像进行傅立叶变换处理的失真，消除了图像上照明不均的问题，增强了暗区的图像细节，同时又不损失亮区的图像细节。