[TOC]

# Hw4 Image Restoration

## Q1：

Implement a blurring filter using the equation in textbook, and blur the test image `book_cover.jpg` using parameters a=b=0.1 and T=1. 

### Algorithm

功能函数：`function [output_img, H] = blurring_filter(a, b, T)`，其中`a`, `b`, `T`为待定值, `output_img`为输出图像，`H`为退化函数矩阵：

- 读取图像获得图像矩阵`I`，获取图像的尺寸大小`m`和`n`；

- 用函数`meshgrid()`计算`u`和`v`两个距离图像中心点的偏移量矩阵；

- 用函数`fft2()`对`I`进行傅里叶变换，再用函数`fftshift()`进行中心变换，得到变换矩阵`Fp`；

- 对变换矩阵`Fp`进行运动模糊滤波，设计函数`filter_function(u, v, a, b, T)`，其中`u`, `v`是偏移量矩阵，`a`, `b`, `T`为待定值，运动模糊模型方程为 ：
  $$
  H(u,v)={\frac {T}{\pi(ua+vb)}sin[\pi(ua+vb)]e^{-j\pi(ua+vb)}}
  $$
  令`filter_function(u, v, a, b, T) = H(u, v)`，再用`filter_function(u, v, a, b, T)`乘以`Fp`，得到滤波矩阵`G`；

- 对滤波矩阵`G`用函数`ifftshift()`进行傅里叶反中心变换，再用`ifft2()`进行傅里叶反变换，然后用函数`real()`取实部得到输出图像矩阵`output_img`；

- 由于得到的图像矩阵`output_img`有取实部之后产生的误差，需要用再对`output_img`进行傅里叶变换得到矩阵`LA`，然后用`LA`除以`Fp`得到退化函数矩阵`H`。

### Result

执行命令`blurring_filter(0.1, 0.1, 1)`，得到：

![q1_result](C:\Users\cheny\Desktop\hm4-陈亚楠-16340041\图像\q1\q1_result.png)

## Q2：

Add Gaussian noise of 0 mean and variance of 500 to the blurred image. 

### Algorithm

功能函数`output_img = adding_Gaussian_noise(a, v)`，其中`a`为平均值, `v`为方差，`output_img`为输出图像：

- 读取图像获得图像矩阵`I`，获取图像的尺寸大小`m`和`n`；

- 根据高斯分布模型计算噪声矩阵`n_gaussian`：
  $$
  n\_gaussian = a + sqrt(v) + randn(m,n)；
  $$

- 将原图像矩阵I和噪声矩阵`n_gaussian`相加得到输出图像`output_img`。

### Result

执行命令`adding_Gaussian_noise(0, 500)`，得到：

![q2_result](C:\Users\cheny\Desktop\hm4-陈亚楠-16340041\图像\q2\q2_result.png)

## Q3：

Restore the blurred image and the blurred noisy image using the inverse filter. 

### Algorithm

功能函数`output_img = inverse_filtering()`：

- 读取待处理图像，获得图像矩阵`I`；

- 用函数`fft2()`对`I`进行傅里叶变换，再用函数`fftshift()`进行中心变换，得到变换矩阵`G`；

- 对变换矩阵`G`进行运动逆滤波，利用公式
  $$
  F(u,v) = G(u,v) / H(u,v)
  $$
  用变换矩阵`G`除以变换矩阵`H`，得到逆滤波矩阵`F`；

- 对逆滤波矩阵矩阵`F`用函数`ifftshift()`进行傅里叶反中心变换，再用`ifft2()`进行傅里叶反变换，然后用函数`abs()`取模得到输出图像矩阵`output_img`；

### Result

执行命令`inverse_filtering`，得到运动模糊无噪声图像的处理结果：

![q3_result_blurred](C:\Users\cheny\Desktop\hm4-陈亚楠-16340041\图像\q3\q3_result_blurred.png)

执行命令`inverse_filtering`，得到运动模糊有噪声图像的处理结果：

![q3_result_noise](C:\Users\cheny\Desktop\hm4-陈亚楠-16340041\图像\q3\q3_result_noise.png)

我们可以发现，在无噪声情况下进行还原，逆滤波效果非常好，但是在有噪声情况下进行还原，逆滤波效果非常不好，甚至无法显示原图像的轮廓。

## Q4：

Restore the blurred noisy image using the parametric Wiener filter with at least 3
different parameters, and compare and analyze results with that of 3. 

### Algorithm

功能函数`output_img = Wiener_filtering(K)`，其中`K`为待定参数值，`output_img`为输出图像：

- 读取待处理图像，获得图像矩阵`I`，获取图像的尺寸大小`m`和`n`；

- 用函数`fft2()`对`I`和`original_img`进行傅里叶变换，再用函数`fftshift()`进行中心变换，得到变换矩阵`G`和`F`；

- 对变换矩阵`G`进行维纳滤波，利用公式
  $$
  F(u,v)={\frac {|H(u,v)|^2}{|H(u,v)|^2+K}·\frac{G(u，v)}{H(u,v)}}
  $$
  遍历整个矩阵进行循环遍历，用公式计算还原矩阵`F2`；

- 对逆滤波矩阵`F2`用函数`ifftshift()`进行傅里叶反中心变换，再用`ifft2()`进行傅里叶反变换，然后用函数`abs()`取模得到输出图像矩阵`output_img`；

### Result

- $K = 0$：

  ![q4_result_k0](C:\Users\cheny\Desktop\hm4-陈亚楠-16340041\图像\q4\q4_result_k0.png)

- $K = 0.1$：

  ![q4_result_k01](C:\Users\cheny\Desktop\hm4-陈亚楠-16340041\图像\q4\q4_result_k01.png)

- $K = 0.5$：

  ![q4_result_k05](C:\Users\cheny\Desktop\hm4-陈亚楠-16340041\图像\q4\q4_result_k05.png)

当K = 0时，维纳滤波就是逆滤波，处理的图像与逆滤波处理的图像效果完全相同；

我们比较K = 0.1和0.5时的图像处理效果，随着K的增大，噪声过滤效果越好，但是图像清晰度和亮度下降，所以综合上述情况，当K = 0.1时，处理后的图像既能较好地消除噪声影响，又能保留较好的清晰度和亮度。