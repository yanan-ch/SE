function output_img = adding_Gaussian_noise(a, v)
    [I, H] = blurring_filter(0.1, 0.1, 1);
    [m,n] = size(I);
    n_gaussian = a + sqrt(v) .* randn(m,n);
    output_img = uint8(double(I) + n_gaussian);
    figure;
    subplot(1,2,1),imshow(I),title('Before Add Gaussian Noise');
    subplot(1,2,2),imshow(output_img),title('After Add Gaussian Noise');
    