function output_img = inverse_filtering()
    % [I, H] = blurring_filter(0.1, 0.1, 1);
    [TEMP, H] = blurring_filter(0.1, 0.1, 1);
    I = adding_Gaussian_noise(0, 500);
    G = fftshift(fft2(I));
    F = G ./ H;
    output_img = uint8(abs(ifft2(fftshift(F))));
    figure;
    % subplot(1,2,1),imshow(I),title('Blurred Before Inverse');
    % subplot(1,2,2),imshow(output_img),title('Blurred After Inverse');
    subplot(1,2,1),imshow(I),title('Noise Before Inverse');
    subplot(1,2,2),imshow(output_img),title('Noise After Inverse');