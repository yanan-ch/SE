function [output_img, H] = blurring_filter(a, b, T)
    I = imread('book_cover.jpg');
    [m,n] = size(I);
    [v,u] = meshgrid(1:n,1:m);
    u = u - floor(m / 2);
    v = v - floor(n / 2);
    Fp = fftshift(fft2(I));
    G = filter_function(u, v, a, b, T) .* Fp;
    output_img = uint8(real(ifft2(ifftshift(G))));
    LA = fftshift(fft2(output_img));
    H = LA ./ double(Fp);
    figure;
    subplot(1,2,1),imshow(I),title('Before blurring');
    subplot(1,2,2),imshow(output_img),title('After blurring');