function output_img = Wiener_filtering(K)
    [I, H] = blurring_filter(0.1, 0.1, 1);
    original_img = imread('book_cover.jpg');
    [m, n] = size(I);
    G = fftshift(fft2(I));
    for u = 1:m
        for v = 1:n  
            H0(u, v) = (abs(H(u,v)))^2;
            H1(u, v) = H0(u,v) / (H(u,v) * (H0(u,v) + K));  
            F2(u, v) = H1(u,v) * G(u,v);
        end
    end
    output_img = uint8(abs(ifft2(ifftshift(F2))));

    M = adding_Gaussian_noise(0, 500);
    [p, q] = size(M);
    GM = fftshift(fft2(M));
    for u = 1:p
        for v = 1:q
            H0(u, v) = (abs(H(u,v)))^2;
            H1(u, v) = H0(u,v) / (H(u,v) * (H0(u,v) + K));  
            F2(u, v) = H1(u,v) * GM(u,v);
        end
    end
    output_img_2 = uint8(abs(ifft2(ifftshift(F2))));
    figure;
    subplot(2,2,1),imshow(I),title('Blurred Before Wiener');
    subplot(2,2,2),imshow(output_img),title('Blurred After Wiener');

    subplot(2,2,3),imshow(M),title('Noise Before Wiener');
    subplot(2,2,4),imshow(output_img_2),title('Noise After Wiener');