#include "md5.hpp"

int main(int argc, char const* argv[]) {
	string testStr;
	cout << "Input Origin Message:\n";
	getline(cin, testStr);
	const unsigned char* data = (const unsigned char*)testStr.c_str();
	cout << "Message After MD5:\n";
	cout << md5(data, testStr.length());
	return 0;
}