#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "table.h"

#define true 1
#define false 0

typedef char bool;

//明文填充
void PKCS5Padding(byte *src, byte *dest) {
    int len = strlen(src);
    int count = 8 - len % 8;
    memcpy(dest, src, len * sizeof(byte));
    for (int i = 0; i < count; i++) {
        dest[len + i] = count;
    }
}

//通用置换函数
//table[0] = 0
void transform(byte *src, int srcSize, int destSize, byte *table) {
    byte copy[srcSize + 1];
    memcpy(copy, src, (srcSize + 1) * sizeof(byte));
    memset(src, 0, destSize * sizeof(byte));
    for (int i = 1; i <= destSize; i++) {
        src[i] = copy[table[i]];
    }
}

//左移
void leftShift(byte *src) {
    byte cHead = src[1], dHead = src[29];
    for (int i = 1; i < 28; i++) {
        src[i] = src[i + 1];
        src[i + 28] = src[i + 1 + 28];
    }
    src[28] = cHead;
    src[56] = dHead;
}

//生成子密钥
//总计16个子密钥，每个子密钥48位长
void generateSubKey(byte *key, byte keys[17][49]) {
    //对给定密钥进行PC1置换
    transform(key, 64, 56, PC1Table);
    for (int i = 1; i <= 16; i++) {
        //左移
        if (i != 1 && i != 2 && i != 9 && i != 16) {
            leftShift(key);
        }
        leftShift(key);
        byte copy[65];
        //key64位
        memcpy(copy, key, 65 * sizeof(byte));
        transform(key, 64, 48, PC2Table);
        for(int j = 1; j <= 48; j++) {
            keys[i][j] = key[j];
        }
        memcpy(key, copy, 65 * sizeof(byte));
    }
}

//S盒转换
void SBoxTransform(byte *dest, byte * src, int i) {
    int begin = 6 * i - 5;
    int n = src[begin] * 2 + src[begin + 5];
    int m = src[begin + 1] * 8 + src[begin + 2] * 4
            + src[begin + 3] * 2 + src[begin + 4];
    int index = SBox[i - 1][n][m];
    //6位to4位
    for (int j = 0; j < 4; j++) {
        dest[4 - j + (i - 1) * 4] = index % 2;
        index >>= 1;
    }
}

//feistel轮函数
void feistelFun(byte *dest, byte *src, byte key[49]) {
    //E-扩展
    memcpy(dest, src, 33 * sizeof(byte));
    transform(dest, 48, 48, ETable);
    //E与子密钥进行异或运算
    for (int i = 1 ; i <= 48; i++) {
        dest[i] ^= key[i];
    }
    byte copy[49];
    memcpy(copy, dest, 49 * sizeof(byte));
    //S盒转换
    for (int i = 1; i <= 8; i++) {
        SBoxTransform(dest, copy, i);
    }
    //P-置换
    transform(dest, 32, 32, PTable);
}

//迭代T
void iterationT(byte * src, byte keys[17][49], bool isEncrypt) {
    for (int i = 1; i <= 16; i++) {
        byte newRight[65], right[33], feistel[33];
        for (int j = 1; j <= 32; j++) {
            newRight[j] = src[32 + j];
            right[j] = src[j];
        }
        if(isEncrypt) {
            feistelFun(feistel, newRight, keys[17 - i]);
        } else {
            feistelFun(feistel, newRight, keys[i]);
        }
        for (int j = 1; j <= 32; j++) {
            right[j] ^= feistel[j];
        }
        for (int j = 1; j <= 32; j++) {
            newRight[32 + j] = right[j];
        }
        memcpy(src, newRight, 65 * sizeof(byte));
    }
    byte copy[65];
    memcpy(copy, src, 65 * sizeof(byte));
    for (int j = 1; j <= 32; j++) {
        src[j] = copy[j + 32];
        src[j + 32] = copy[j];
    }
}

void to64(byte *src, byte *dest) {
  for (int i = 0; i < 8; i++) {
    byte cur = src[i];
    for (int j = 0; j < 8; j++) {
      dest[(8 - j) + i * 8] = cur % 2;
      cur >>= 1;
    }
  }
}

void to8(byte *src, byte *dest) {
  for (int i = 1; i <= 8; i++) {
    byte b;
    for (int j = 1; j <= 8; j++) {
      b <<= 1;
      if (src[(i - 1) * 8 + j] == 1) b |= 1;
    }
    dest[i - 1] = b;
  }
}

//DES算法主函数
byte *des(byte *src, byte *key, bool isEncrypt, int *len) {
    if (strlen(key) != 8) {
        printf("Key length must be 8!\n");
        return src;
    }
    if (isEncrypt) {
        *len = strlen(src) + 8 - strlen(src) % 8;
    } else {
        *len = strlen(src);
    }
    byte *dest = malloc(*len * sizeof(byte));
    memset(dest, 0, *len * sizeof(byte));
    // 生成16个子密钥
    byte keys[17][49];
    byte keyBit[65];
    to64(key, keyBit);
    generateSubKey(keyBit, keys);
    //补全
    if (isEncrypt) {
        PKCS5Padding(src, dest);
    } else {
        memcpy(dest, src, *len * sizeof(byte));
    }
    int times = strlen(dest) / 8;
    for (int i = 0; i < times; i++) {
        //分割64位
        byte raw[8];
        for (int j = 0; j < 8; j++) {
            raw[j] = dest[i * 8 + j];
        }
        byte bit[65];
        to64(raw, bit);
        //IP变换
        transform(bit, 64, 64, IPTable);
        //T-迭代&&W-置换
        iterationT(bit, keys, !isEncrypt);
        //IP逆置换
        transform(bit, 64, 64, IPInverseTable);
        to8(bit, raw);
        for (int j = 0; j < 8; j++) {
            dest[i * 8 + j] = raw[j];
        }
    }
    return dest;
}

//加密
byte *encrypt(byte *plain, byte *key, int *len) {
  return des(plain, key, true, len);
}

//解密
byte *decode(byte *cipher, byte *key, int len) {
  int t = 0;
  byte *plain = des(cipher, key, false, &t);
  //删除PKCS5填充
  plain[len - plain[len - 1]] = '\0';
  return plain;
}