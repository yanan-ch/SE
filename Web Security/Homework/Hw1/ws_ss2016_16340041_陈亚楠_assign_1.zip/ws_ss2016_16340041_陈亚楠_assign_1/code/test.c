#include "des.h"

int main() {
    byte key[10] = "swchenyn";
    byte plain[100] = "hello,des!";
    printf("Assuming 8 Byte Key: %s\n", key);
    int len = 0;
    byte *ciphertext = encrypt(plain, key, &len);
    byte *originPLain = decode(ciphertext, key, len);
    printf("Result:\n");
    printf("PlainText: %s\n", plain);
    printf("Ciphertext: ");
    for (int i = 0; i < len; i++) {
        printf("%x", ciphertext[i]);
    }
    printf("\n");
    printf("Plain after decoding: %s\n", originPLain);
    free(ciphertext);
    free(originPLain);
    return 0;
}