
# coding: utf-8

# In[2]:


# q1
import torch
import numpy as np
import matplotlib.pyplot as plt

xs = torch.load('xs.pt')
ys = torch.load('ys.pt')
x = xs.numpy()
y = ys.numpy()

dimen = x.shape[0]
print([(x[i], y[i]) for i in range(dimen)])

para = np.polyfit(x, y, 3)
poly = np.poly1d(para)

plt.scatter(x, y)
xp = np.linspace(-1, 6, 100)
plt.plot(xp, poly(xp), color = 'orange')
plt.show()


# In[3]:


# q2
import torch

x = torch.arange(0,40.0) + 10

print(x)
print(torch.max(x))
print(torch.min(x))


# In[5]:


# q3
import torch

def convolve(matrix, kernel):
    m = matrix.shape[0]
    f = kernel.shape[0]
    convolution = torch.zeros(m-2, m-2)

    for x in range(m-f+1):
        for y in range(m-f+1):
            tmp = matrix[x:x+f, y:y+f]
            convolution[x, y] = (tmp * kernel).sum()
    
    return convolution

def main(matrix1, kernel1, matrix2, kernel2):
    convolve1 = convolve(matrix1, kernel1)
    convolve2 = convolve(matrix2, kernel2)
    result = convolve1 + convolve2
    print(result)
    return

def test():
    matrix1 = torch.Tensor([[0, 0, 0, 0, 0, 0, 0], [0, 1, 0, 1, 2, 1, 0], [0, 0, 2, 1, 0, 1, 0], [0, 1, 1, 0, 2, 0, 0], [0, 2, 2, 1, 1, 0, 0], [0, 2, 0, 1, 2, 0, 0], [0, 0, 0, 0, 0, 0, 0]])
    kernel1 = torch.Tensor([[1, 0, 1], [-1, 1, 0], [0, -1, 0]])
    matrix2 = torch.Tensor([[0, 0, 0, 0, 0, 0, 0], [0, 2, 0, 2, 1, 1, 0], [0, 0, 1, 0, 0, 2, 0], [0, 1, 0, 0, 2, 1, 0], [0, 1, 1, 2, 1, 0, 0], [0, 1, 0, 1, 1, 1, 0], [0, 0, 0, 0, 0, 0, 0]])
    kernel2 = torch.Tensor([[-1, 0, 1], [0, 0, 1], [1, 1, 1]])
    main(matrix1, kernel1, matrix2, kernel2)
    return

test()

