
# coding: utf-8

# In[2]:


import math
class Activation:
    def sigmoid(self,x):
        #todo
        res = 1 / (1 + math.exp(-x))
        return res
    pass
    def tanh(self,x):
        #todo
        res = (math.exp(x) - math.exp(-x)) / (math.exp(x) + math.exp(-x))
        return res
        pass
    def relu(self,x):
        #todo
        if x >= 0:
            return x
        else:
            return 0
        pass
    def leaky_relu(self,alpha,x):
        #todo
        if x >= 0:
            return x
        else:
            return alpha * x
        pass
    def elu(self,alpha,x):
        #todo
        if x >= 0:
            return x
        else:
            return alpha * (math.exp(x) - 1)
        pass

activation = Activation()
print(activation.sigmoid(10))
print(activation.relu(20))
print(activation.tanh(-1))
print(activation.leaky_relu(0.1, -1))
print(activation.elu(0.1, -1))

