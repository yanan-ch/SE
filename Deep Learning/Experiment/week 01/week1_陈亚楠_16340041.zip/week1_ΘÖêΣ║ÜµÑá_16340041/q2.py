
# coding: utf-8

# In[3]:


import os
 
path = './face'
list = [ ]
print('There are all images:')
for root, dirs, files in os.walk(path):
    for img in files:
        list.append(img)
        print(img)
lenth = len(list)
print('\nThe number of images are %d.' % (lenth))

